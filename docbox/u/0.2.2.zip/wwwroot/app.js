/* 숨길이 서류보관함 화면. 이 PC의 서류함 프로그램(/api)과만 이야기한다. 모양과 흐름은 시안(시안/index.html) 그대로.
   지키는 것: 환자가 확정되기 전에는 서류를 보여 주지 않는다 · 넣다 만 줄은 그 환자에게 남는다 · 늦게 온 답은 버린다 ·
   저장하는 동안에는 환자를 바꾸지 못한다 · 목록의 줄 위에는 파일을 놓을 수 없다. */
'use strict';
const IC={
 folder:'<path d="M3 6.5A1.5 1.5 0 0 1 4.5 5h4l2 2.5h9A1.5 1.5 0 0 1 21 9v9.5a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 18.5z"/>',
 search:'<circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/>',
 user:'<circle cx="12" cy="8" r="3.6"/><path d="M4.5 20c.8-3.8 3.9-5.5 7.5-5.5s6.7 1.7 7.5 5.5"/>',
 report:'<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4M9 17v-3M12 17v-6M15 17v-2"/>',
 cal:'<rect x="3.5" y="5" width="17" height="15" rx="2"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
 gear:'<circle cx="12" cy="12" r="3"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1"/>',
 up:'<path d="M12 16V5M7.5 9.5 12 5l4.5 4.5M5 19h14"/>',check:'<path d="m5 12.5 4.5 4.5L19 7.5"/>',x:'<path d="M6 6l12 12M18 6 6 18"/>',
 alert:'<path d="M12 4 2.8 19.5h18.4z"/><path d="M12 10v4.5M12 17.2v.3"/>',
 down:'<path d="M12 5v11M7.5 11.500 12 16l4.500-4.500M5 19h14"/>',print:'<path d="M7 8V4h10v4M7 17H4.500v-7h15v7H17"/><rect x="7" y="14" width="10" height="6"/>',
 trash:'<path d="M4.500 7h15M9 7V4.500h6V7M6.500 7l1 12.500h9l1-12.500"/>',move:'<path d="M4 12h14M13 7l5 5-5 5"/>',
 pc:'<rect x="3" y="4.500" width="18" height="12" rx="1.500"/><path d="M8.500 20h7M12 16.500V20"/>',file:'<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4"/>',
 left:'<path d="m14.500 6-6 6 6 6"/>',right:'<path d="m9.500 6 6 6-6 6"/>',edit:'<path d="M4 20h4L19 9l-4-4L4 16z"/>'
};
const ic=(n,s=18)=>`<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${IC[n]||''}</svg>`;
const chip=(t,k='')=>`<span class="chip ${k}">${t}</span>`;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const STAGE={first:'최초',adapting:'순응중',after:'순응후'};
const USE={claim:'월 청구용',compliance:'순응 평가용',unknown:'미확인'};
const PERIOD_TYPES=['rx','proxy'];

const S={scene:'patient',patients:[],types:[],pid:null,docs:[],docsFor:null,tab:'all',lq:'',lf:'all',ls:'todo',order:[],
  up:[],held:[],pend:{},saving:false,modal:null,seq:0,online:true,status:null,flash:false,newIds:[],keep:false,snap:null,setup:null,wiz:null,link:'',restarting:false,
  admin:null,bform:null,bmsg:null,trash:null,audit:null,check:null,checking:false,openSeq:0,openWait:null,batch:null,claim:null};
const typeName=c=>(S.types.find(t=>t.code===c)||{name:c}).name;
const required=()=>S.types.filter(t=>t.required);
const entry=id=>S.patients.find(x=>x.patient.boxNo===id);
const pat=id=>{const e=entry(id);return e&&e.patient;};

/* ---------- 서버와 이야기하기 ---------- */
async function api(path,opt={}){
  try{
    const r=await fetch(path,{cache:'no-store',...opt});let body=null;try{body=await r.json();}catch(e){}
    body=body||{};setOnline(true);
    const own=path.startsWith('/api/setup')||path==='/api/health';
    if(['store_offline','store_changed','unpaired'].includes(body.code)){if(S.link!==body.code){S.link=body.code;render();}}
    else if(!own&&r.ok&&S.link){S.link='';render();}
    return {status:r.status,ok:r.ok,body};
  }catch(e){setOnline(false);return {status:0,ok:false,body:{error:'서류함 프로그램과 이어지지 않습니다.'}};}
}
function setOnline(v){if(S.online!==v){S.online=v;render();}}
const jsonBody=o=>({method:o.method||'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(o.body)});
async function loadTypes(){const r=await api('/api/types');if(r.ok)S.types=r.body.types;}
async function loadPatients(){const r=await api('/api/patients?all=1');if(r.ok){const first=!S.patients.length;S.patients=r.body.patients;if(first)S.snap=null;}}
async function loadStatus(){const r=await api('/api/status');if(r.ok)S.status=r.body;}
async function loadSetup(){const r=await api('/api/setup');if(r.ok)S.setup=r.body;return r.ok;}
/* 관리(보관 PC 본체에서만): 백업 · 비상용 목록 · 점검 · 휴지통 · 한 일 기록 */
async function loadAdmin(){if(!S.setup||S.setup.role!=='store'){S.admin=null;return;}const r=await api('/api/admin/overview');
  if(r.ok){S.admin=r.body;if(!S.bform)S.bform={root:r.body.backup.root,at:r.body.backup.at,drill:r.body.backup.state.drillDay||''};}}
const dt=s=>s?new Date(s).toLocaleString('ko-KR',{month:'long',day:'numeric',hour:'2-digit',minute:'2-digit'}):'';
/* 환자를 빨리 바꿀 때 늦게 온 답은 버린다(번호표). */
async function loadDocs(){
  const my=++S.seq,id=S.pid;if(!id){S.docs=[];S.docsFor=null;return;}
  const r=await api(`/api/patients/${id}/docs`);
  if(my!==S.seq||id!==S.pid)return;
  S.docs=r.ok?r.body.docs:[];S.docsFor=id;
}

/* ---------- 환자 바꾸기 ---------- */
const pendN=id=>id===S.pid?S.up.length+S.held.length:((S.pend[id]||{n:0}).n);
async function sel(id){
  if(id===S.pid)return;
  if(S.saving){toast('저장이 끝난 뒤에 바꿉니다.');return;}
  if(S.pid){const n=S.up.length+S.held.length;if(n){S.pend[S.pid]={up:S.up,held:S.held,n};toast(`${esc(pat(S.pid).name)}에게 넣다 만 줄 ${n}건은 그 환자에게 그대로 남겨 두었습니다.`);}else delete S.pend[S.pid];}
  S.pid=id;S.tab='all';S.newIds=[];S.docs=[];S.docsFor=null;
  const pd=id&&S.pend[id];S.up=pd?pd.up:[];S.held=pd?pd.held:[];if(id)delete S.pend[id];S.flash=!!id;
  render();await loadDocs();render();
}

/* ---------- 차트의 서류 버튼(§7): 번호 둘(차트번호 c, 내부 번호 i)로 누구를 열지 정한다 ----------
   바로 여는 것은 두 번호가 모두 맞을 때뿐이다. 그 밖에는 이름과 번호만 보여 주고 사람이 정한다(서류는 환자가 확정된 뒤에만 보인다).
   저장하는 중이면 끝난 뒤에 바꾼다. 넣다 만 줄은 그 환자에게 남는다(sel 이 한다). */
async function openFromChart(c,i){
  if(S.saving){S.openWait={c,i};toast('저장이 끝난 뒤 바꿉니다.');return;}
  if(S.scene==='setup')return;
  const r=await api(`/api/lookup?c=${encodeURIComponent(c)}&i=${encodeURIComponent(i)}`);
  if(!r.ok){toast('차트에서 온 환자를 찾지 못했습니다. '+esc(r.body.error||''));return;}
  const L=r.body;await loadPatients();S.scene='patient';
  if(L.decision==='open'){S.modal=null;await sel(L.patient.boxNo);S.flash=true;S.keep=true;render();const row=document.querySelector('.prow.sel');if(row)row.scrollIntoView({block:'nearest'});return;}
  if(L.decision==='none'){toast('차트가 번호를 보내지 않았습니다.');render();return;}
  S.modal={k:'lookup',L,c,i,error:''};render();
}
async function pollOpen(){
  if(S.restarting||!S.setup||!S.setup.role)return;
  let b;try{const r=await fetch(`/api/open/next?after=${S.openSeq}`,{cache:'no-store'});if(!r.ok)return;b=await r.json();}catch(e){return;}
  /* 차트가 📁 를 누르며 보낸 명단으로 환자가 등록됐다 → 목록을 다시 읽고 알린다(건수만 온다). 여는 청보다 먼저 처리한다. */
  const ro=b.roster;
  if(ro){
    if(ro.busy&&!S.rosterBusy)toast('차트에서 온 환자 명단을 등록하는 중…');
    S.rosterBusy=!!ro.busy;
    if(ro.seq>(S.rosterSeq||0)){S.rosterSeq=ro.seq;
      const seen=S.rosterSeen||{created:0,updated:0,check:0};const nc=ro.created-seen.created,nu=ro.updated-seen.updated;   /* 지난번에 본 뒤로 늘어난 수 */
      S.rosterSeen={created:ro.created,updated:ro.updated,check:ro.check};
      if(nc>0||nu>0){await loadPatients();await loadStatus();S.keep=true;render();}
      const parts=[];if(nc>0)parts.push(`새 환자 ${nc}명 등록`);if(nu>0)parts.push(`${nu}명 고침`);if(ro.check&&(nc>0||nu>0||ro.check!==seen.check))parts.push(`확인이 필요한 ${ro.check}명은 차트에서 그 환자의 📁 를 누를 때 묻습니다`);
      if(parts.length)toast('차트 명단: '+parts.join(' · '));}
  }
  if(b.seq>S.openSeq){S.openSeq=b.seq;if(b.open)openFromChart(b.c,b.i);}
}
const who=x=>`<b style="font-size:19px">${esc(x.name)}</b> <span class="hint">${esc(x.birth6)}</span><div class="mono">${esc(x.chartNo)||'차트번호 없음'}</div>`;
function vLookup(m){
  const L=m.L,d=L.decision,p=L.patient,cs=L.candidates||[];
  const foot=(yes)=>`<div class="row" style="margin-top:14px"><span class="rowst err">${esc(m.error||'')}</span><span class="sp"></span><button class="btn" data-act="close">${yes?'아니요':'닫기'}</button>${yes||''}</div>`;
  const cards=list=>`<div class="side2" style="margin:12px 0">${list.map(x=>`<div class="card" style="box-shadow:none">${who(x)}<div style="margin-top:10px"><button class="btn s" data-act="lk-open" data-id="${x.boxNo}">이 환자 열기</button></div></div>`).join('')}</div>`;
  if(d==='confirm_chart_no') return `<h2>차트번호가 바뀌었습니다</h2><div>차트의 번호가 <b class="mono">${esc(p.chartNo)||'(없음)'}</b> → <b class="mono">${esc(L.newChartNo)}</b> 로 다릅니다. <b>같은 환자가 맞나요?</b></div>
     <div class="card" style="box-shadow:none;margin:12px 0">${who(p)}</div><div class="hint">맞다고 하면 서류함의 차트번호를 ${esc(L.newChartNo)} 로 고치고 엽니다. 아니면 열지 않습니다.</div>
     ${foot(`<button class="btn p" data-act="lk-yes">맞습니다 — 고치고 열기</button>`)}`;
  if(d==='confirm_link') return `<h2>이 환자가 맞나요?</h2><div>차트에서 차트번호 <b class="mono">${esc(m.c)}</b> 의 서류 버튼을 눌렀습니다. 서류함에서는 처음 이어지는 환자입니다.</div>
     <div class="card" style="box-shadow:none;margin:12px 0">${who(p)}</div><div class="hint">맞다고 하면 다음부터는 묻지 않고 바로 엽니다.</div>
     ${foot(`<button class="btn p" data-act="lk-yes">맞습니다 — 열기</button>`)}`;
  if(d==='conflict') return `<h2>${ic('alert',22)} 열지 않았습니다 — 번호가 서로 다른 환자를 가리킵니다</h2><div>차트가 보낸 차트번호 <b class="mono">${esc(m.c)}</b> 와 내부 번호가 서류함에서는 <b>다른 환자</b>입니다. 차트와 서류함의 번호를 확인해 주세요.</div>
     ${cards(cs)}<div class="hint">어느 쪽인지 분명할 때만 직접 골라 여세요. 번호는 저절로 고치지 않습니다.</div>${foot('')}`;
  if(d==='choose') return `<h2>같은 차트번호의 환자가 ${cs.length}명입니다</h2><div>차트번호 <b class="mono">${esc(m.c)}</b> — 누구인지 골라 주세요.</div>${cards(cs)}${foot('')}`;
  if(d==='candidate') return `<h2>이 환자를 열까요?</h2><div class="card" style="box-shadow:none;margin:12px 0">${who(cs[0])}</div>${foot(`<button class="btn p" data-act="lk-open" data-id="${cs[0].boxNo}">열기</button>`)}`;
  return `<h2>서류함에 없는 환자입니다</h2><div>차트번호 <b class="mono">${esc(m.c)||'(없음)'}</b> 의 환자가 서류함에 아직 없습니다. 새 환자로 등록할까요?</div>${foot(`<button class="btn p" data-act="lk-new">새 환자로 등록</button>`)}`;
}

/* ---------- 명단 가져오기(§7-3) ----------
   숨길이 차트가 내보낸 명단 파일을 읽어 **미리보기부터** 보여 준다(이때는 아무것도 바뀌지 않는다). 사람이 보고 [반영]을 눌러야 들어간다.
   번호로만 맞춘다. 서류함에 먼저 있던 환자와 잇는 줄은 체크한 것만, 번호가 엇갈린 줄은 넘기지 않는다. */
async function readRoster(file){
  let roster;try{roster=JSON.parse(await file.text());}catch(e){toast('명단 파일을 읽을 수 없습니다(숨길이 차트에서 내보낸 파일인지 확인해 주세요).');return;}
  const r=await api('/api/patients/sync',jsonBody({body:{roster}}));
  if(!r.ok){toast(esc(r.body.error||'명단을 읽지 못했습니다.'));return;}
  const plan=r.body.plan,links={};plan.rows.filter(x=>x.kind==='link').forEach(x=>links[x.i]=!!x.sameName);
  S.modal={k:'roster',roster,plan,links,error:'',busy:false};render();
}
function vRoster(m){
  const pl=m.plan,rows=k=>pl.rows.filter(x=>x.kind===k),picked=rows('link').filter(x=>m.links[x.i]).length,n=pl.new+pl.update+picked;
  const sec=(title,list,cols,kind)=>list.length?`<div class="grp" style="margin-top:12px">${title} ${list.length}</div><div style="max-height:190px;overflow:auto"><table class="grid"><tbody>${list.map(x=>`<tr>${kind==='link'?`<td style="width:34px"><input type="checkbox" data-act="roster-link" data-i="${esc(x.i)}" ${m.links[x.i]?'checked':''} ${m.busy?'disabled':''} title="같은 환자가 맞습니다"></td>`:''}<td class="mono" style="width:90px">${esc(x.c)||'—'}</td><td style="width:150px"><b>${esc(x.name)||'<span class="hint">(이름 없음)</span>'}</b></td>${cols?`<td class="hint" style="font-size:12.5px">${esc(x.note)}</td>`:'<td></td>'}</tr>`).join('')}</tbody></table></div>`:'';
  return `<div class="row"><h2 style="margin:0">명단 가져오기 — 미리보기</h2><span class="sp"></span><button class="btn s" data-act="close" ${m.busy?'disabled':''}>${ic('x',15)}닫기</button></div>
    <div class="row wrap" style="margin-top:10px"><span class="chip g">새로 ${pl.new}</span><span class="chip b">바뀜 ${pl.update}</span><span class="chip b">잇기 ${pl.link}</span><span class="chip a">확인 필요 ${pl.conflict}</span><span class="chip">그대로 ${pl.same}</span>${pl.bad?`<span class="chip r">읽을 수 없음 ${pl.bad}</span>`:''}</div>
    <div class="note">아직 아무것도 바뀌지 않았습니다. 아래를 보고 <b>[반영]</b>을 눌러야 들어갑니다. 번호(차트 내부 번호 · 차트번호)로만 맞추고, 이름으로는 맞추지 않습니다.</div>
    ${sec('새로 등록',rows('new'),false)}${sec('바뀜 — 차트의 값으로 고칩니다',rows('update'),true)}
    ${sec('서류함에 먼저 있던 환자와 잇기 — 체크한 줄만',rows('link'),true,'link')}
    ${sec('넘기지 않습니다 — 번호가 엇갈림(서류함에서 번호를 확인해 주세요)',rows('conflict'),true)}${sec('읽을 수 없는 줄',rows('bad'),true)}
    ${pl.notInRoster?`<div class="hint" style="margin-top:10px;font-size:12.5px">명단에 없는 서류함 환자 ${pl.notInRoster}명은 그대로 둡니다.</div>`:''}
    <div class="row" style="margin-top:14px"><span class="rowst err">${esc(m.error||'')}</span><span class="sp"></span><button class="btn" data-act="close" ${m.busy?'disabled':''}>취소</button><button class="btn p" data-act="roster-commit" ${n&&!m.busy?'':'disabled'}>${m.busy?'반영하는 중…':`${n}명 반영`}</button></div>`;
}

/* ---------- 오른쪽 환자 목록 ---------- */
function missing(e){return required().filter(t=>!(e.types&&e.types[t.code]));}
const phase=p=>p.state==='returned'?'반납':(p.state==='use'?'사용':'');
function listData(){
  let rows=S.patients.map(e=>{const m=missing(e);return {e,p:e.patient,m,s:m.length*10+(pendN(e.patient.boxNo)?1:0)};});
  const cnt={all:rows.length,use:rows.filter(x=>x.p.state!=='returned').length,end:rows.filter(x=>x.p.state==='returned').length,todo:rows.filter(x=>x.s>0).length};
  const f=S.lf;rows=rows.filter(x=>f==='all'||(f==='use'&&x.p.state!=='returned')||(f==='end'&&x.p.state==='returned')||(f==='todo'&&x.s>0));
  const q=S.lq.trim().toLowerCase();if(q)rows=rows.filter(x=>(x.p.name+' '+x.p.chartNo+' '+x.p.birth6).toLowerCase().includes(q));
  const byNo=(a,b)=>((!a.p.chartNo)-(!b.p.chartNo))||a.p.chartNo.localeCompare(b.p.chartNo)||(a.p.boxNo-b.p.boxNo);
  /* 목록의 순서는 보는 동안 저절로 바뀌지 않는다(저장해서 할 일이 줄어도 줄이 튀지 않게): 순서용 점수는 처음과 [순서] 단추를 누를 때만 다시 잡는다. */
  if(!S.snap){S.snap={};rows.forEach(x=>S.snap[x.p.boxNo]=x.s);}
  const rank=x=>S.snap[x.p.boxNo]??x.s;
  rows.sort((a,b)=>S.ls==='no'?byNo(a,b):((rank(b)-rank(a))||byNo(a,b)));S.order=rows.map(x=>x.p.boxNo);return {rows,cnt};
}
function listRows(rows){
  const st=x=>{const o=[];if(x.m.length)o.push(chip('빠짐 '+x.m.length,'r'));const n=pendN(x.p.boxNo);if(n)o.push(chip('넣다 만 '+n,'a'));return o.join('')||`<span class="ok">${ic('check',15)}</span>`;};
  return `<div class="prow h"><span>차트번호</span><span>이름</span><span>서류</span></div>`+(rows.map(x=>`<div class="prow ${x.p.boxNo===S.pid?'sel':''}" data-act="open" data-id="${x.p.boxNo}"><span class="no mono">${esc(x.p.chartNo)||'—'}</span><span class="nm">${esc(x.p.name)} <span class="hint" style="font-weight:400;font-size:12px">${phase(x.p)}</span></span><span class="st">${st(x)}</span></div>`).join('')
    ||`<div class="empty" style="padding:30px 12px">${S.patients.length?'맞는 환자가 없습니다.':'아직 환자가 없습니다.<br>[새 환자]로 등록하세요.'}</div>`);
}
function vList(){
  const {rows,cnt}=listData();const fc=(k,l)=>`<button class="fchip ${S.lf===k?'on':''}" data-act="lf" data-k="${k}">${l}<em>${cnt[k]}</em></button>`;
  return `<aside class="plist"><div class="hd"><h3>환자 목록</h3><span class="hint">${cnt.all}명 · ${S.ls==='no'?'차트번호 순':'서류 할 일 순'}</span><span class="sp"></span><button class="btn s" data-act="ls">${S.ls==='no'?'할 일 순':'번호 순'}</button></div>
   <div class="tools"><div class="search" style="max-width:none">${ic('search',16)}<input id="lq" placeholder="이름 · 차트번호 · 생년월일" value="${esc(S.lq)}" autocomplete="off"></div>
    <div class="fl">${fc('all','전체')}${fc('use','사용')}${fc('end','반납')}${fc('todo','서류 할 일')}</div></div>
   <div class="prows">${listRows(rows)}</div>
   <div class="row" style="padding:8px 12px;border-top:1px solid var(--line)"><span class="hint" style="font-size:12px">↑↓ 로 이동</span><span class="sp"></span><button class="btn s" data-act="roster-pick" title="숨길이 차트에서 내보낸 명단 파일로 환자 목록을 맞춥니다">명단 가져오기</button><button class="btn s" data-act="new-patient">${ic('user',14)}새 환자</button>
     <input type="file" id="rfile" accept=".json,application/json" style="display:none"></div></aside>`;
}

/* ---------- 달마다 사용 보고서(점검표의 달 띠) ----------
   준비됨: 그 달의 월 청구용 제출본이 하나 정해짐(같은 달에 둘이면 사람이 고른 것만) · 확인 필요: 보고서는 있는데 낼 것이 정해지지 않음 · 빠짐.
   계약 전 · 반납 뒤의 달은 대상이 아니라 그리지 않는다. 판정은 서버(이번 달 청구)와 같은 규칙이다. */
const ym=d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;
function monthState(docs){
  if(!docs.length)return 'gap';const sub=docs.filter(d=>d.submit),claims=docs.filter(d=>d.use==='claim').length;
  return sub.length===1&&sub[0].use==='claim'&&(claims===1||sub[0].submitBy==='user')?'c':'q';
}
function monthStrip(p){
  const now=new Date(),end=p.returnDay?new Date(p.returnDay):now,months=[];
  const use=S.docs.filter(d=>d.type==='usage'&&d.month);
  /* 언제부터 대상인지: 계약 시작일. 모르면 가장 이른 보고서의 달부터(그 앞은 알 수 없으니 빠짐이라고 하지 않는다). 길어도 최근 열두 달. */
  let from=null;
  if(p.contractStart){const c=new Date(p.contractStart);from=new Date(c.getFullYear(),c.getMonth(),1);}
  else if(use.length){const m=use.map(d=>d.month).sort()[0].split('-');from=new Date(+m[0],+m[1]-1,1);}
  if(!from)return `<div class="hint" style="margin-top:10px;font-size:12px">환자 정보에 계약 시작일을 적으면 달마다 빠진 사용 보고서를 보여 줍니다.</div>`;
  const cap=new Date(now.getFullYear(),now.getMonth()-11,1);if(from<cap)from=cap;
  /* 이번 달은 아직 끝나지 않았다(보고서는 달이 지난 뒤에 내려받는다) → 지난달까지만 본다. */
  const limit=new Date(now.getFullYear(),now.getMonth(),1);
  for(let d=new Date(from);d<=end&&d<limit;d=new Date(d.getFullYear(),d.getMonth()+1,1))months.push(ym(d));
  if(!months.length)return '';
  const cells=months.map(m=>{const st=monthState(use.filter(d=>d.month===m));const lab={c:'있음',q:'확인',gap:'빠짐'}[st];
    return `<span class="cell ${st}" title="${m} 사용 보고서 — ${lab}">${+m.slice(5)}</span>`;}).join('');
  const gaps=months.filter(m=>monthState(use.filter(d=>d.month===m))==='gap').length;
  return `<div style="margin-top:12px;font-size:12.5px;font-weight:700">달마다 사용 보고서 <span class="hint" style="font-weight:400">${months[0].replace('-','.')} ~ ${months[months.length-1].replace('-','.')}${gaps?` · 빠진 달 ${gaps}`:''}</span></div>
    <div class="mstrip">${cells}</div><div class="legend"><span><i style="background:var(--greenbg)"></i>낼 것 정해짐</span><span><i style="background:var(--amberbg)"></i>확인 필요</span><span><i style="background:var(--redbg)"></i>빠짐</span></div>`;
}

/* ---------- 환자 화면 ---------- */
const when=d=>d.type==='usage'&&d.month?d.month.replace('-','년 ')+'월':(d.periodFrom||d.periodTo?`${d.periodFrom||'?'} ~ ${d.periodTo||'?'}`:(d.docDate||''));
function vPatient(){
  const e=entry(S.pid);
  if(!e) return `<div class="pt"><div class="card empty" style="grid-column:span 2">${ic('user',40)}<div style="font-size:19px;font-weight:800;color:var(--ink);margin-top:6px">환자를 고르세요</div>오른쪽 <b>환자 목록</b>에서 누르면 바로 열립니다.<br>차트에서 서류 버튼을 눌러도 그 환자가 열립니다.<div class="hint" style="margin-top:10px">환자를 고르기 전에는 파일을 넣을 수 없습니다.</div></div>${vList()}</div>`;
  const p=e.patient,ready=S.docsFor===p.boxNo,have={};S.docs.forEach(d=>have[d.type]=(have[d.type]||0)+1);
  const req=required(),got=req.filter(t=>have[t.code]).length;
  const chk=req.map(t=>{const n=have[t.code]||0;return `<li>${n?`<span class="ok">${ic('check')}</span>`:`<span class="no">${ic('x')}</span>`}<span>${esc(t.name)}</span><span class="n">${n?n+'건':'<b class="no">빠짐</b>'}</span></li>`;}).join('');
  const left=`<div><div class="card ${S.flash?'flash':''}"><div class="pname">${esc(p.name)}</div><div class="pno mono">${esc(p.chartNo)||'차트번호 없음'}</div>
     <div class="row wrap" style="margin-top:8px">${phase(p)?chip(phase(p),p.state==='returned'?'':'g'):''}<span class="hint">${esc(p.birth6)}</span><span class="sp"></span><button class="btn s" data-act="edit-patient" title="환자 정보 고치기">${ic('edit',14)}</button></div>
     ${p.contractStart||p.returnDay?`<dl class="kv" style="margin:12px 0 0">${p.contractStart?`<dt>계약 시작</dt><dd>${esc(p.contractStart)}</dd>`:''}${p.returnDay?`<dt>반납</dt><dd>${esc(p.returnDay)}</dd>`:''}</dl>`:''}
     ${p.memo?`<div class="hint" style="margin-top:8px">${esc(p.memo)}</div>`:''}</div>
    <div class="card" style="margin-top:12px"><h3>점검표 <span class="hint">${ready?`필수 ${got}/${req.length}`:'불러오는 중…'}</span></h3>${ready?`<ul class="check">${chk}</ul>`:''}
     ${ready?monthStrip(p):''}</div></div>`;
  const tabs=[['all','전체',S.docs.length]].concat(S.types.filter(t=>have[t.code]).map(t=>[t.code,t.name,have[t.code]]));
  const docs=S.docs.filter(d=>S.tab==='all'||d.type===S.tab);
  const card=d=>`<div class="doc ${S.newIds.includes(d.id)?'new':''}" data-act="view" data-id="${d.id}">${d.thumbPath?`<img class="thumbimg" loading="lazy" alt="" src="/api/docs/${d.id}/thumb">`:`<div class="pdfcard">${ic('file',30)}<span>${d.kind.toUpperCase()}${d.pages>1?` · ${d.pages}쪽`:''}</span></div>`}
     <div class="t">${d.stage?chip(STAGE[d.stage],'b'):(['rx','contract'].includes(d.type)?chip('단계 미확인','a'):'')}${d.use?chip(USE[d.use],d.use==='unknown'?'a':(d.use==='claim'?'g':'')):''}</div>
     <div class="d">${esc(when(d))||'<span class="qq">날짜 미확인</span>'}</div>${d.scanDate?`<div class="d">스캔 ${esc(d.scanDate)}</div>`:''}${d.submit?`<div class="d ok">제출본</div>`:''}</div>`;
  const groups=S.types.filter(t=>docs.some(d=>d.type===t.code)).map(t=>`<div class="grp">${esc(t.name)} ${docs.filter(d=>d.type===t.code).length}</div><div class="docs">${docs.filter(d=>d.type===t.code).map(card).join('')}</div>`).join('');
  const right=`<div>${vUpload(p)}
    ${ready?`<div class="tabs">${tabs.map(([c,n,k])=>`<button data-act="tab" data-t="${c}" class="${S.tab===c?'on':''}">${esc(n)} ${k}</button>`).join('')}</div>
    ${S.docs.length?groups:'<div class="card hint">아직 넣은 서류가 없습니다. 위의 [파일 넣기]로 시작하세요.</div>'}`:'<div class="card hint" style="margin-top:12px">서류를 불러오는 중…</div>'}</div>`;
  return `<div class="pt">${left}${right}${vList()}</div>`;
}
function vUpload(p){
  const opt=(v,cur,l)=>`<option ${v===cur?'selected':''} value="${v}">${esc(l)}</option>`;
  const dateCell=(u,i)=>u.type==='usage'
    ?`<input type="month" value="${esc(u.month)}" data-chg="month" data-i="${i}" title="청구 달">`
    :PERIOD_TYPES.includes(u.type)
      ?`<div class="period"><input type="date" value="${esc(u.from)}" data-chg="from" data-i="${i}" title="기간 시작"><div class="row" style="gap:4px"><span class="hint">~</span><input type="date" value="${esc(u.to)}" data-chg="to" data-i="${i}" title="기간 끝"></div></div>`
      :`<input type="date" value="${esc(u.date)}" data-chg="date" data-i="${i}" title="문서 날짜(모르면 비워 둠)">`;
  const rows=S.up.map((u,i)=>`<div class="uprow">${u.thumbUrl?`<img class="upthumb" alt="" src="${u.thumbUrl}">`:`<div class="upthumb pdf">${u.kind.toUpperCase()}</div>`}
     <div style="align-self:center"><span class="mono" style="font-size:13px">${esc(u.name)}</span> <span class="hint" style="font-size:12px;margin-left:6px;white-space:nowrap">스캔 ${esc(u.scan)}</span>
       ${u.state==='saving'?'<span class="rowst"> · 저장 중…</span>':u.state==='error'?`<span class="rowst err"> · ${esc(u.error)}</span>`:''}</div>
     <div><select data-chg="type" data-i="${i}" style="${u.type?'':'border-color:var(--amber)'}">${opt('',u.type,'종류를 골라 주세요')}${S.types.map(t=>opt(t.code,u.type,t.name)).join('')}</select>
        ${u.typeFrom?`<div style="margin-top:3px">${chip(u.typeFrom,'b')}</div>`:''}${u.read==='reading'&&!u.type?'<div class="hint" style="font-size:12px;margin-top:3px">종류 읽는 중…</div>':''}
        ${u.cands&&u.cands.length&&!u.type?`<div class="row wrap" style="margin-top:3px;gap:4px"><span class="hint" style="font-size:12px">후보</span>${u.cands.map(c=>`<button class="btn s" data-act="pick-type" data-i="${i}" data-t="${esc(c)}">${esc(typeName(c))}</button>`).join('')}</div>`:''}
        ${u.guide&&!u.type?`<div style="margin-top:3px">${chip('안내문으로 보입니다','a')}<div class="hint" style="font-size:12px">서류가 아니면 [빼기]</div></div>`:''}</div>
     <div><select data-chg="stage" data-i="${i}">${['','first','adapting','after'].map(s=>opt(s,u.stage,s?STAGE[s]:'단계 미확인')).join('')}</select>${u.stageHint?`<div style="margin-top:3px"><button class="btn s" data-act="hint-stage" data-i="${i}">제안: ${STAGE[u.stageHint]}</button></div>`:''}</div>
     <div>${dateCell(u,i)}</div>
     <div class="hint" style="font-size:12px">${(u.size/1024/1024).toFixed(1)}MB</div><button class="btn s" data-act="up-del" data-i="${i}" title="빼기" ${S.saving?'disabled':''}>${ic('x',14)}</button></div>`).join('');
  const held=S.held.length?`<div class="held"><div class="row" style="font-weight:700;color:var(--amber)">${ic('alert')}하나씩 확인이 필요한 줄 ${S.held.length} <span class="hint" style="font-weight:400">· [저장]을 눌러도 이 줄은 들어가지 않습니다</span></div>
    ${S.held.map((h,i)=>`<div class="hrow">${h.thumbUrl?`<img class="upthumb" alt="" src="${h.thumbUrl}">`:`<div class="upthumb pdf">${h.kind.toUpperCase()}</div>`}<div style="flex:1"><div class="mono" style="font-size:12.500px">${esc(h.name)}</div><div>${h.why}</div></div>
      <button class="btn s" data-act="held-ok" data-i="${i}" ${S.saving?'disabled':''}>그래도 ${esc(p.name)}에게 넣기</button><button class="btn s" data-act="held-del" data-i="${i}" ${S.saving?'disabled':''}>빼기</button></div>`).join('')}</div>`:'';
  const ready=S.up.filter(u=>u.type).length;
  return `<div class="card ${S.flash?'flash':''}"><div class="drop" id="drop"><button class="btn p big" data-act="pick-files" ${S.saving?'disabled':''}>${ic('up',20)}파일 넣기</button>
     <div><b>${esc(p.name)} <span class="mono">${esc(p.chartNo)}</span></b> 에게 넣습니다<div class="hint">스캔한 파일을 이름 그대로 고르거나, 여기에 끌어다 놓으세요. PDF · JPG · PNG</div></div>
     <input type="file" id="files" multiple accept=".pdf,.jpg,.jpeg,.png,application/pdf,image/jpeg,image/png" style="display:none"></div>
    ${rows}${held}
    ${S.up.length?`<div class="row" style="margin-top:12px"><span class="hint">${S.up.length-ready?`종류를 고르지 않은 줄 ${S.up.length-ready}건은 남습니다.`:'날짜와 단계는 몰라도 저장할 수 있습니다.'}</span><span class="sp"></span>
      <button class="btn p big" data-act="save" ${ready&&!S.saving?'':'disabled'}>${ic('check',20)}${esc(p.name)} (${esc(p.chartNo)||'번호 없음'}) 에게 ${ready}건 저장</button></div>`:''}</div>`;
}

/* ---------- 파일을 줄로 ---------- */
const hex=b=>[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('');
const newId=()=>hex(crypto.getRandomValues(new Uint8Array(16)));
function kindOf(h){return h[0]===0x25&&h[1]===0x50&&h[2]===0x44&&h[3]===0x46&&h[4]===0x2d?'pdf':h[0]===0xff&&h[1]===0xd8&&h[2]===0xff?'jpg':h[0]===0x89&&h[1]===0x50&&h[2]===0x4e&&h[3]===0x47?'png':'';}
const day=d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
function scanDayOf(file){
  const m=file.name.match(/(?:^|\D)(20\d{2})(\d{2})(\d{2})(?:\D|$)/);
  if(m){const d=new Date(+m[1],+m[2]-1,+m[3]);if(d.getMonth()===+m[2]-1&&d.getDate()===+m[3])return day(d);}
  return day(new Date(file.lastModified||Date.now()));
}
/* 이름을 붙여 둔 옛 파일(§8-8)과 LMTS 가 붙인 이름(§8-5)에서 읽을 수 있는 것. 종류를 글자 읽기로 채우는 것은 classifyRows(보관 PC가 읽는다). */
const NAME_WORDS=[['처방전','rx'],['계약서','contract'],['위임장','proxy'],['동의서','consent'],['CMS','cms'],['신분증','id'],['등록','reg'],['수면다원','psg']];
function readName(name,p){
  const o={type:'',typeFrom:'',stageHint:'',month:'',from:'',to:'',chartNo:''};
  const l=name.match(/^([A-Za-z]\d{5})_.*_(20\d{2})(\d{2})(\d{2})_(20\d{2})(\d{2})(\d{2})\.pdf$/i);
  if(l){o.type='usage';o.typeFrom='파일 이름(LMTS)';o.chartNo=l[1];o.from=`${l[2]}-${l[3]}-${l[4]}`;o.to=`${l[5]}-${l[6]}-${l[7]}`;
    const last=new Date(+l[5],+l[6],0).getDate();if(l[4]==='01'&&+l[7]===last&&l[2]===l[5]&&l[3]===l[6])o.month=`${l[2]}-${l[3]}`;return o;}
  const hit=NAME_WORDS.find(([w])=>name.toUpperCase().includes(w.toUpperCase()));
  if(hit){o.type=hit[1];o.typeFrom='파일 이름';}
  if(name.includes('순응후'))o.stageHint='after';else if(name.includes('순응중'))o.stageHint='adapting';
  return o;
}
async function thumbOf(file){
  try{
    const bmp=await createImageBitmap(file);const k=Math.min(1,320/Math.max(bmp.width,bmp.height));
    const c=document.createElement('canvas');c.width=Math.max(1,Math.round(bmp.width*k));c.height=Math.max(1,Math.round(bmp.height*k));
    c.getContext('2d').drawImage(bmp,0,0,c.width,c.height);bmp.close&&bmp.close();
    return await new Promise(r=>c.toBlob(r,'image/jpeg',0.8));
  }catch(e){return null;}
}
async function addFiles(files){
  const id=S.pid,p=pat(id);if(!p||S.saving)return;
  let bad=0;const up=[],held=[];
  for(const file of files){
    const head=new Uint8Array(await file.slice(0,8).arrayBuffer());const kind=kindOf(head);
    if(!kind||file.size>40*1024*1024||file.size<5){bad++;continue;}
    const n=readName(file.name,p);const thumb=kind==='pdf'?null:await thumbOf(file);
    /* LMTS 가 붙인 이름의 날짜는 보고서 기간이지 스캔한 날이 아니다 → 파일을 받은 때를 적는다 */
    const row={id:newId(),file,name:file.name,kind,size:file.size,scan:n.chartNo?day(new Date(file.lastModified||Date.now())):scanDayOf(file),type:n.type,typeFrom:n.typeFrom,stage:'',stageHint:n.stageHint,date:'',from:n.from,to:n.to,month:n.month,
      use:n.type==='usage'?(n.month?'claim':'unknown'):'',thumb,thumbUrl:thumb?URL.createObjectURL(thumb):'',state:'',error:'',confirm:false};
    if(n.chartNo&&p.chartNo&&n.chartNo.toUpperCase()!==p.chartNo.toUpperCase()){row.why=`파일 이름의 차트번호 <b>${esc(n.chartNo)}</b> 가 이 환자(${esc(p.chartNo)})와 다릅니다.`;held.push(row);}
    else up.push(row);
  }
  if(id!==S.pid){toast('환자가 바뀌어 넣지 않았습니다. 다시 넣어 주세요.');return;}
  S.up.push(...up);S.held.push(...held);S.keep=true;render();
  if(bad)toast(`넣을 수 없는 파일 ${bad}개를 뺐습니다. (PDF · JPG · PNG, 40MB 까지)`);
  classifyRows([...up,...held]);
}
/* 종류 자동 채우기(§8-3): 보관 PC가 파일을 읽고 제안한다. 확실할 때만 종류 칸을 채우고, 비슷한 것이 둘이면 후보를 보여 주고, 모르면 비워 둔다.
   사람이 이미 고른 줄은 건드리지 않는다. 저장은 언제나 사람이 [저장]을 눌러야 된다. PDF 는 이때 첫 쪽 미리보기와 쪽수도 받는다. */
const rowAlive=u=>S.up.includes(u)||S.held.includes(u)||Object.values(S.pend).some(x=>x.up.includes(u)||x.held.includes(u));
async function classifyRows(rows){
  for(const u of rows){
    if(u.read||!rowAlive(u))continue;u.read='reading';S.keep=true;render();
    const form=new FormData();form.append('file',u.file,u.name);
    const r=await api('/api/classify',{method:'POST',body:form});u.read='done';
    if(r.ok){const b=r.body;
      if(b.pages>1)u.pages=b.pages;
      if(b.thumb&&!u.thumb){try{const bin=atob(b.thumb),a=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)a[i]=bin.charCodeAt(i);u.thumb=new Blob([a],{type:'image/jpeg'});u.thumbUrl=URL.createObjectURL(u.thumb);}catch(e){}}
      if(b.sure&&b.sure!=='none'){u.autoType=b.type;u.autoSure=b.sure;
        if(b.type==='guide')u.guide=true;
        else if(!u.type&&!u.touched){
          if(b.sure==='high'){u.type=b.type;u.typeFrom='자동';if(b.type==='usage')u.use=u.month?'claim':'unknown';}
          else u.cands=(b.candidates||[]).map(c=>c.type).filter(t=>t!=='guide');}}
    }
    if(rowAlive(u)&&(S.up.includes(u)||S.held.includes(u))){S.keep=true;render();}
  }
}
function dropRow(u){if(u.thumbUrl)URL.revokeObjectURL(u.thumbUrl);}

/* ---------- 저장 ---------- */
async function saveAll(){
  const id=S.pid,p=pat(id);if(!p||S.saving)return;
  const go=S.up.filter(u=>u.type);if(!go.length)return;
  S.saving=true;S.newIds=[];S.keep=true;render();
  let done=0,dup=0,held=0,failed=0;
  for(const u of go){
    u.state='saving';u.error='';S.keep=true;render();
    const buf=await u.file.arrayBuffer();const sha=hex(await crypto.subtle.digest('SHA-256',buf)).toUpperCase();
    const meta={id:u.id,boxNo:id,type:u.type,stage:u.stage,docDate:u.date,periodFrom:u.from,periodTo:u.to,month:u.month,scanDate:u.scan,use:u.use,fileName:u.name,origin:'drop',sha256:sha,confirmSameContent:u.confirm,
      autoType:u.autoType||'',autoSure:u.autoSure||'',pages:u.pages||1};
    const form=new FormData();form.append('meta',JSON.stringify(meta));form.append('file',new Blob([buf]),u.name);if(u.thumb)form.append('thumb',u.thumb,'thumb.jpg');
    const r=await api('/api/docs',{method:'POST',body:form});const code=r.body.code;
    if(r.status===201||code==='exists'){done++;S.newIds.push(u.id);u.state='done';}
    else if(code==='duplicate'){dup++;u.state='done';}
    else if(code==='same_content_other_patient'){held++;u.state='held';const who=(r.body.data.patients||[]).map(x=>`${esc(x.name)} ${esc(x.chartNo)}`).join(', ');u.why=`같은 내용의 파일이 <b>다른 환자</b>(${who})에게 이미 있습니다.`;}
    else{failed++;u.state='error';u.error=r.body.error||'저장하지 못했습니다.';}
  }
  S.held.push(...S.up.filter(u=>u.state==='held'));
  S.up.filter(u=>u.state==='done').forEach(dropRow);
  S.up=S.up.filter(u=>u.state!=='done'&&u.state!=='held');
  S.saving=false;
  await Promise.all([loadPatients(),loadDocs(),loadStatus()]);S.keep=true;render();
  const rest=S.up.filter(u=>!u.type).length;
  if(S.openWait){const w=S.openWait;S.openWait=null;setTimeout(()=>openFromChart(w.c,w.i),1200);}
  toast(`${esc(p.name)}에게 ${done}건 저장했습니다.`+(dup?` 이미 있던 것 ${dup}건은 넣지 않았습니다.`:'')+(held?` 확인이 필요한 줄 ${held}건이 남았습니다.`:'')+(failed?` 저장하지 못한 줄 ${failed}건이 남았습니다.`:'')+(rest?` 종류를 고르지 않은 줄 ${rest}건이 남았습니다.`:''));
}

/* ---------- 창(모달) ---------- */
function vModal(){
  const m=S.modal;if(!m)return '';
  const wrap=(inner,wide)=>`<div class="shade" data-act="shade"><div class="dlg ${wide?'wide':''}">${inner}</div></div>`;
  const opt=(v,cur,l)=>`<option ${v===cur?'selected':''} value="${v}">${esc(l)}</option>`;
  if(m.k==='view'){const p=pat(S.pid),d=S.docs.find(x=>x.id===m.id);if(!p||!d)return '';
    const f=m.f;const body=d.kind==='pdf'?`<iframe class="viewer" title="서류" src="/api/docs/${d.id}/file"></iframe>`:`<img class="viewimg" alt="서류" src="/api/docs/${d.id}/file">`;
    return wrap(`<div class="row"><h2 style="margin:0">${esc(typeName(d.type))}</h2>${d.stage?chip(STAGE[d.stage],'b'):''}${d.use?chip(USE[d.use],d.use==='unknown'?'a':'g'):''}${d.submit?chip('제출본','g'):''}<span class="sp"></span><button class="btn s" data-act="close">${ic('x',15)}닫기</button></div>
     <div class="row" style="align-items:flex-start;gap:18px;margin-top:12px"><div style="flex:1.5;min-width:0">${body}</div>
      <div style="flex:1;min-width:300px"><div class="card" style="box-shadow:none"><b style="font-size:18px">${esc(p.name)}</b> <span class="mono pno" style="font-size:15px">${esc(p.chartNo)}</span>
       <div class="field" style="margin-top:12px"><label>종류</label><select data-f="type">${S.types.map(t=>opt(t.code,f.type,t.name)).join('')}</select>
        <label>단계</label><select data-f="stage">${['','first','adapting','after'].map(s=>opt(s,f.stage,s?STAGE[s]:'미확인')).join('')}</select>
        ${f.type==='usage'?`<label>청구 달</label><input type="month" data-f="month" value="${esc(f.month)}"><label>용도</label><select data-f="use">${['','claim','compliance','unknown'].map(s=>opt(s,f.use,s?USE[s]:'—')).join('')}</select>
        <label>제출본</label><label class="row" style="gap:8px;cursor:pointer;color:var(--ink)"><input type="checkbox" data-f="submit" style="width:auto" ${f.submit?'checked':''}> 이 달 청구에 <b>이 보고서를 냅니다</b></label>`:''}
        ${PERIOD_TYPES.includes(f.type)||f.type==='usage'?`<label>기간</label><div class="row" style="gap:4px"><input type="date" data-f="periodFrom" value="${esc(f.periodFrom)}"><span>~</span><input type="date" data-f="periodTo" value="${esc(f.periodTo)}"></div>`:`<label>문서 날짜</label><input type="date" data-f="docDate" value="${esc(f.docDate)}">`}
        <label>메모</label><textarea data-f="note" rows="2" maxlength="500">${esc(f.note)}</textarea></div>
       <div class="row" style="margin-top:10px"><span class="rowst err">${esc(m.error||'')}</span><span class="sp"></span><button class="btn p" data-act="doc-save">고친 것 저장</button></div>
       <dl class="kv" style="margin-top:12px;font-size:13px"><dt>스캔한 날</dt><dd>${esc(d.scanDate)||'—'}</dd><dt>넣은 때</dt><dd>${esc(new Date(d.receivedUtc).toLocaleString('ko-KR'))} · ${esc(d.station)}</dd><dt>파일 이름</dt><dd class="mono" style="word-break:break-all">${esc(d.fileName)||'—'}</dd><dt>크기</dt><dd>${(d.bytes/1024/1024).toFixed(2)}MB</dd></dl></div>
       <div class="row wrap" style="margin-top:12px"><a class="btn" href="/api/docs/${d.id}/file?download=1" download>${ic('down')}원본 내려받기</a><a class="btn" href="/api/docs/${d.id}/file" target="_blank" rel="noopener">${ic('print')}새 창에서 열기 · 인쇄</a></div>
       <div class="row wrap" style="margin-top:8px"><button class="btn" data-act="move-pick">${ic('move')}다른 환자로 옮기기</button><button class="btn danger" data-act="del-ask">${ic('trash')}휴지통</button></div></div></div>`,true);}
  if(m.k==='del'){const p=pat(S.pid),d=S.docs.find(x=>x.id===m.id);if(!p||!d)return '';
    return wrap(`<h2>${ic('trash',22)} 휴지통으로 보낼까요?</h2><div class="card" style="box-shadow:none;margin:12px 0"><b style="font-size:19px">${esc(p.name)}</b> <span class="mono pno" style="font-size:15px">${esc(p.chartNo)}</span><div style="margin-top:6px">${esc(typeName(d.type))} · ${esc(when(d))||'날짜 미확인'}</div></div>
     <div class="hint">파일은 지워지지 않고 휴지통 폴더로 갑니다. 되살리기는 보관 PC의 설정·관리 → 휴지통에서 합니다.</div><div class="row" style="margin-top:14px"><span class="rowst err">${esc(m.error||'')}</span><span class="sp"></span><button class="btn" data-act="view" data-id="${d.id}">취소</button><button class="btn p" data-act="del-ok">휴지통으로</button></div>`);}
  if(m.k==='move'){const p=pat(S.pid),d=S.docs.find(x=>x.id===m.id);if(!p||!d)return '';
    const q=(m.q||'').trim().toLowerCase();const cands=S.patients.map(e=>e.patient).filter(x=>x.boxNo!==p.boxNo&&(!q||(x.name+' '+x.chartNo+' '+x.birth6).toLowerCase().includes(q)));
    const to=m.to&&pat(m.to);
    return wrap(`<h2>${ic('move',22)} 다른 환자로 옮기기</h2><div>${esc(typeName(d.type))} · 지금 주인 <b>${esc(p.name)}</b> <span class="mono">${esc(p.chartNo)}</span></div>
     ${to?`<div class="side2" style="margin:14px 0"><div class="card" style="box-shadow:none"><div class="hint">지금</div><b style="font-size:20px">${esc(p.name)}</b> <span class="hint">${esc(p.birth6)}</span><div class="mono">${esc(p.chartNo)||'번호 없음'}</div></div>
        <div class="card" style="box-shadow:none;border-color:var(--accent)"><div class="hint">옮길 곳</div><b style="font-size:20px">${esc(to.name)}</b> <span class="hint">${esc(to.birth6)}</span><div class="mono">${esc(to.chartNo)||'번호 없음'}</div></div></div>
        <div class="row"><span class="rowst err">${esc(m.error||'')}</span><span class="sp"></span><button class="btn" data-act="move-back">다시 고르기</button><button class="btn p" data-act="move-ok">${esc(to.name)}에게 옮기기</button></div>`
      :`<div class="search" style="max-width:none;margin:12px 0 8px">${ic('search',16)}<input id="mq" placeholder="옮길 환자 찾기" value="${esc(m.q||'')}" autocomplete="off"></div>
        <div class="pick prows" id="mrows">${moveRows(cands)}</div><div class="row" style="margin-top:12px"><span class="sp"></span><button class="btn" data-act="view" data-id="${d.id}">취소</button></div>`}`);}
  if(m.k==='lookup') return wrap(vLookup(m));
  if(m.k==='roster') return wrap(vRoster(m),true);
  if(m.k==='pair'){const q=m.req;
    return wrap(`<h2>${ic('pc',22)} '${esc(q.name)}'가 연결하려고 합니다</h2><div>그 PC 화면의 숫자와 <b>같으면</b> 허용하세요. 다르면 거절하세요.</div>
     <div class="digits">${[...q.code].map(c=>`<span>${esc(c)}</span>`).join('')}</div>
     <div class="hint" style="text-align:center">허용하면 그 PC에서 이 서류함의 서류를 보고 넣을 수 있습니다.</div>
     <div class="row" style="margin-top:14px"><span class="rowst err">${esc(m.error||'')}</span><span class="sp"></span><button class="btn" data-act="pair-deny">거절</button><button class="btn p" data-act="pair-allow">허용</button></div>`);}
  if(m.k==='reset') return wrap(`<h2>역할을 다시 고를까요?</h2><div>프로그램이 다시 켜지고 '이 PC를 어떻게 쓸까요?'부터 시작합니다.</div>
     <div class="note">자료 폴더와 서류는 지우지 않습니다. ${S.setup&&S.setup.role==='store'?'보관을 그만두면 연결된 다른 PC에서 서류를 볼 수 없게 됩니다.':'보관 PC에 받아 둔 연결은 이 PC에서 지워집니다.'}</div>
     <div class="row" style="margin-top:14px"><span class="sp"></span><button class="btn" data-act="close">취소</button><button class="btn p" data-act="reset-ok">다시 고르기</button></div>`);
  if(m.k==='revoke') return wrap(`<h2>'${esc(m.name)}'의 연결을 해제할까요?</h2><div>해제하면 그 PC에서 바로 서류를 볼 수 없게 됩니다. 다시 쓰려면 그 PC에서 다시 연결해야 합니다.</div>
     <div class="row" style="margin-top:14px"><span class="rowst err">${esc(m.error||'')}</span><span class="sp"></span><button class="btn" data-act="close">취소</button><button class="btn p" data-act="revoke-ok">해제</button></div>`);
  if(m.k==='patient'){const f=m.f;
    return wrap(`<h2>${m.id?'환자 정보 고치기':'새 환자 등록'}</h2><div class="field" style="margin-top:12px"><label>이름</label><input data-f="name" value="${esc(f.name)}" maxlength="60" autocomplete="off">
      <label>차트번호</label><input data-f="chartNo" value="${esc(f.chartNo)}" maxlength="20" placeholder="A00000" autocomplete="off" class="mono">
      <label>생년월일</label><input data-f="birth6" value="${esc(f.birth6)}" maxlength="6" placeholder="6자리 (예: 650101)" inputmode="numeric" autocomplete="off">
      <label>상태</label><select data-f="state">${opt('',f.state,'—')}${opt('use',f.state,'사용')}${opt('returned',f.state,'반납')}</select>
      <label>계약 시작</label><input type="date" data-f="contractStart" value="${esc(f.contractStart||'')}">
      <label>반납한 날</label><input type="date" data-f="returnDay" value="${esc(f.returnDay||'')}">
      <label>메모</label><textarea data-f="memo" rows="2" maxlength="1000">${esc(f.memo)}</textarea></div>
     <div class="hint" style="margin-top:8px">차트와 명단을 맞추면 이 값들은 차트에서 옵니다(다음 단계). 주민번호 뒷자리는 넣지 않습니다.</div>
     ${m.warn?`<div class="note a">${esc(m.warn)}</div>`:''}
     <div class="row" style="margin-top:14px"><span class="rowst err">${esc(m.error||'')}</span><span class="sp"></span><button class="btn" data-act="close">취소</button><button class="btn p" data-act="patient-save">${m.id?'저장':'등록'}</button></div>`);}
  return '';
}
const moveRows=c=>c.map(x=>`<div class="prow" data-act="move-to" data-id="${x.boxNo}"><span class="no mono">${esc(x.chartNo)||'—'}</span><span class="nm">${esc(x.name)} <span class="hint" style="font-weight:400;font-size:12px">${esc(x.birth6)}</span></span><span></span></div>`).join('')||'<div class="empty" style="padding:24px">맞는 환자가 없습니다.</div>';
const docForm=d=>({type:d.type,stage:d.stage,docDate:d.docDate,periodFrom:d.periodFrom,periodTo:d.periodTo,month:d.month,use:d.use,note:d.note,submit:!!d.submit});

/* ---------- 틀 ---------- */
/* ---------- 사용 보고서 한꺼번에 넣기(§8-5) ----------
   LMTS 에서 내려받은 PDF(이름: <차트번호>_<이름>_<시작일>_<끝일>.pdf)를 한꺼번에 놓는다. 파일 이름의 차트번호로 환자를 찾아 표에 올린다.
   **줄마다 사람이 확인해야 들어간다**(이름으로는 맞추지 않는다. 차트번호 하나만 믿고 여러 명에게 넣지 않는다).
   그 달의 제출본이 아직 없는 환자에게는 이것이 제출본이 된다. 이미 있으면 바꾸지 않는다(이번 달 청구에서 고른다). */
const LMTS=/^([A-Za-z]\d{5})_(.+)_(20\d{2})(\d{2})(\d{2})_(20\d{2})(\d{2})(\d{2})\.pdf$/i;
const newBatch=()=>({id:hex(crypto.getRandomValues(new Uint8Array(8))),rows:[],busy:false,done:null});
async function addBatchFiles(files){
  const B=S.batch||(S.batch=newBatch());if(B.busy)return;if(B.done){S.batch=newBatch();return addBatchFiles(files);}
  let bad=0;const fresh=[];
  for(const file of files){
    const head=new Uint8Array(await file.slice(0,8).arrayBuffer());
    if(kindOf(head)!=='pdf'||file.size>40*1024*1024){bad++;continue;}
    if(B.rows.some(r=>r.name===file.name&&r.size===file.size))continue;
    const row={id:newId(),file,name:file.name,size:file.size,ok:false,state:'',error:'',chartNo:'',from:'',to:'',month:'',use:'unknown',p:null,why:'',pages:1,thumb:null};
    const m=file.name.match(LMTS);
    if(!m)row.why='파일 이름에 차트번호가 없습니다 — 그 환자 화면에서 넣어 주세요.';
    else{row.chartNo=m[1].toUpperCase();row.from=`${m[3]}-${m[4]}-${m[5]}`;row.to=`${m[6]}-${m[7]}-${m[8]}`;
      const last=new Date(+m[6],+m[7],0).getDate();
      if(m[5]==='01'&&+m[8]===last&&m[3]===m[6]&&m[4]===m[7]){row.month=`${m[3]}-${m[4]}`;row.use='claim';}
      const hit=S.patients.map(e=>e.patient).filter(x=>(x.chartNo||'').toUpperCase()===row.chartNo);
      if(hit.length===1)row.p=hit[0];else row.why=hit.length?`차트번호 ${esc(row.chartNo)} 인 환자가 ${hit.length}명입니다 — 그 환자 화면에서 넣어 주세요.`:`차트번호 ${esc(row.chartNo)} 인 환자가 서류함에 없습니다.`;
      if(row.p&&!row.month)row.why='한 달 전체(1일~말일)가 아닙니다 — 청구 달과 용도를 정해야 하니 그 환자 화면에서 넣어 주세요.';}
    B.rows.push(row);fresh.push(row);
  }
  render();if(bad)toast(`PDF 가 아닌 파일 ${bad}개를 뺐습니다.`);
  /* 보관 PC가 첫 쪽을 읽어 본다: 사용 보고서가 아닌 것으로 보이면 알리고, 미리보기 그림과 쪽수를 받는다. */
  for(const r of fresh){if(!S.batch||!S.batch.rows.includes(r))break;
    const form=new FormData();form.append('file',r.file,r.name);const a=await api('/api/classify',{method:'POST',body:form});
    if(a.ok){const b=a.body;r.pages=b.pages||1;if(b.thumb)r.thumb=b.thumb;
      if(b.sure==='high'&&b.type!=='usage')r.warn=`사용 보고서가 아니라 '${b.type==='guide'?'안내문':esc(typeName(b.type))}'(으)로 보입니다.`;
      if(r.pages>1&&r.use==='claim'){r.use='unknown';r.warn=(r.warn?r.warn+' ':'')+`${r.pages}쪽짜리입니다(월 청구용은 한 쪽) — 용도를 확인해야 합니다.`;}}
    if(S.scene==='usage'&&!S.batch.busy)render();}
}
const batchReady=r=>r.p&&r.month&&!r.why&&r.state!=='done';
async function saveBatch(){
  const B=S.batch;if(!B||B.busy)return;const go=B.rows.filter(r=>batchReady(r)&&r.ok);if(!go.length)return;
  B.busy=true;render();let done=0,dup=0,fail=0,n=0;
  for(const r of go){
    r.state='saving';render();n++;
    const buf=await r.file.arrayBuffer();const sha=hex(await crypto.subtle.digest('SHA-256',buf)).toUpperCase();
    const meta={id:r.id,boxNo:r.p.boxNo,type:'usage',periodFrom:r.from,periodTo:r.to,month:r.month,use:r.use,fileName:r.name,origin:'batch',batch:B.id,batchRow:n,sha256:sha,submitIfFirst:true,pages:r.pages||1,autoType:'usage',autoSure:'name'};
    const form=new FormData();form.append('meta',JSON.stringify(meta));form.append('file',new Blob([buf]),r.name);
    if(r.thumb){try{const bin=atob(r.thumb),a=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)a[i]=bin.charCodeAt(i);form.append('thumb',new Blob([a],{type:'image/jpeg'}),'thumb.jpg');}catch(e){}}
    const a=await api('/api/docs',{method:'POST',body:form});const code=a.body.code;
    if(a.status===201){done++;r.state='done';r.note=a.body.data.doc.submit?'넣음 · 그 달의 제출본':'넣음 · 그 달에 다른 보고서가 이미 있어 제출본은 그대로';}
    else if(code==='exists'||code==='duplicate'){dup++;r.state='done';r.note='이미 들어 있음';}
    else{fail++;r.state='error';r.error=code==='same_content_other_patient'?'같은 내용의 파일이 다른 환자에게 이미 있습니다 — 그 환자 화면에서 확인하고 넣어 주세요.':(a.body.error||'넣지 못했습니다.');}
  }
  B.busy=false;B.done={done,dup,fail};await Promise.all([loadPatients(),loadStatus()]);render();
  toast(`사용 보고서 ${done}건을 넣었습니다.`+(dup?` 이미 있던 것 ${dup}건.`:'')+(fail?` 넣지 못한 것 ${fail}건.`:''));
}
function vUsage(){
  const B=S.batch||{rows:[],busy:false,done:null};const rows=B.rows,can=rows.filter(batchReady),picked=can.filter(r=>r.ok).length;
  const st=r=>r.state==='done'?`<span class="ok">${ic('check',14)} ${esc(r.note||'넣음')}</span>`:r.state==='saving'?'넣는 중…':r.state==='error'?`<span class="no">${esc(r.error)}</span>`
    :r.why?`<span class="qq">${r.why}</span>`:(r.warn?`<span class="qq">${ic('alert',13)} ${r.warn}</span>`:'<span class="hint">이름을 보고 확인해 주세요</span>');
  const tr=(r,i)=>`<tr class="${r.why?'dim':''}"><td>${batchReady(r)?`<input type="checkbox" data-act="batch-ok" data-i="${i}" ${r.ok?'checked':''} ${B.busy?'disabled':''} title="이 환자의 보고서가 맞습니다">`:''}</td>
     <td>${r.p?`<b>${esc(r.p.name)}</b> <span class="hint">${esc(r.p.birth6)}</span>`:'<span class="hint">—</span>'}</td><td class="mono">${esc(r.chartNo)||'—'}</td>
     <td>${r.month?esc(r.month.replace('-','년 '))+'월':(r.from?`${esc(r.from)} ~ ${esc(r.to)}`:'—')}</td><td>${r.use==='claim'?chip('월 청구용','g'):chip('미확인','a')}</td>
     <td class="mono" style="font-size:12px;word-break:break-all">${esc(r.name)}</td><td style="font-size:13px">${st(r)}</td>
     <td>${r.state==='done'||B.busy?'':`<button class="btn s" data-act="batch-del" data-i="${i}" title="빼기">${ic('x',13)}</button>`}</td></tr>`;
  return `<h2>사용 보고서 한꺼번에 넣기</h2>
   <div class="card" style="margin-top:12px"><div class="drop" id="bdrop"><button class="btn p big" data-act="batch-pick" ${B.busy?'disabled':''}>${ic('up',20)}보고서 넣기</button>
     <div><b>LMTS 에서 내려받은 그 달의 PDF 를 한꺼번에</b><div class="hint">파일 이름(<span class="mono">차트번호_이름_시작일_끝일.pdf</span>)은 바꾸지 말고 그대로 놓으세요. 파일 이름의 차트번호로 환자를 찾습니다.</div></div>
     <input type="file" id="bfiles" multiple accept=".pdf,application/pdf" style="display:none"></div>
    ${rows.length?`<div class="note">${ic('alert',15)} <b>줄마다 이름을 보고 체크해야 들어갑니다.</b> 체크한 줄만 [넣기]로 들어갑니다. 기기 번호·기간까지 저절로 대조하는 것은 차트와 명단을 맞춘 뒤에 됩니다.</div>
     <div style="overflow:auto"><table class="grid"><thead><tr><th>확인</th><th>환자</th><th>차트번호</th><th>달</th><th>용도</th><th>파일 이름</th><th>상태</th><th></th></tr></thead><tbody>${rows.map(tr).join('')}</tbody></table></div>
     <div class="row" style="margin-top:12px">${B.done?`<span>넣음 ${B.done.done} · 이미 있음 ${B.done.dup} · 못 넣음 ${B.done.fail}</span><button class="btn" data-act="batch-undo" ${B.done.done?'':'disabled'}>이 묶음 되돌리기</button><button class="btn" data-act="batch-new">새로 시작</button>`
        :`<span class="hint">확인할 수 있는 줄 ${can.length} · 체크한 줄 ${picked}${rows.length-can.length?` · 여기서 넣을 수 없는 줄 ${rows.length-can.length}`:''}</span>`}
      <span class="sp"></span>${B.done?`<button class="btn p" data-act="scene" data-s="claim">이번 달 청구 보기</button>`:`<button class="btn p big" data-act="batch-save" ${picked&&!B.busy?'':'disabled'}>${ic('check',20)}체크한 ${picked}건 넣기</button>`}</div>`
    :'<div class="hint" style="margin-top:12px">한 명 치만 넣거나, 이름에 차트번호가 없는 보고서(순응 평가용 8쪽 등)는 <b>환자 화면</b>에서 그 환자를 고른 뒤 넣습니다.</div>'}</div>`;
}

/* ---------- 이번 달 청구 서류(§8-6) ---------- */
const prevMonth=()=>{const d=new Date();return ym(new Date(d.getFullYear(),d.getMonth()-1,1));};
async function loadClaim(){const C=S.claim||(S.claim={month:prevMonth(),data:null,out:null,busy:false});const r=await api(`/api/claims/${C.month}`);C.data=r.ok?r.body:null;}
function vClaim(){
  const C=S.claim;if(!C||!C.data)return `<h2>이번 달 청구 서류</h2><div class="card hint" style="margin-top:12px">불러오는 중…</div>`;
  const d=C.data,c=d.counts,ST={ready:['준비됨','g'],check:['확인 필요','a'],missing:['빠짐','r'],na:['대상 아님','']},order={check:0,missing:1,ready:2,na:3};
  const rows=d.rows.slice().sort((a,b)=>(order[a.state]-order[b.state])||String(a.c).localeCompare(String(b.c)));
  const tr=r=>{const p=pat(r.boxNo)||{name:'(목록에 없음)',birth6:''};
    return `<tr class="rowlink ${r.state==='na'?'dim':''}" data-act="open" data-id="${r.boxNo}"><td class="mono">${esc(r.c)||'—'}</td><td><b>${esc(p.name)}</b> <span class="hint">${esc(p.birth6)}</span></td><td>${chip(...ST[r.state])}</td>
     <td style="font-size:13px">${r.state==='ready'?`<span class="mono" style="font-size:12px;word-break:break-all">${esc(r.doc.fileName)}</span>`:esc(r.why)||(r.state==='missing'?'그 달의 사용 보고서가 없습니다':'')}</td><td class="hint" style="font-size:12px">${r.docs?`보고서 ${r.docs}건`:''}</td></tr>`;};
  const o=C.out;
  return `<h2>이번 달 청구 서류</h2>
   <div class="card" style="margin-top:12px"><div class="row wrap"><button class="btn s" data-act="claim-move" data-d="-1">${ic('left',14)}</button><input type="month" id="cmonth" value="${esc(C.month)}"><button class="btn s" data-act="claim-move" data-d="1">${ic('right',14)}</button>
      <span class="chip g">준비됨 ${c.ready}</span><span class="chip a">확인 필요 ${c.check}</span><span class="chip r">빠짐 ${c.missing}</span><span class="chip">대상 아님 ${c.na}</span><span class="sp"></span>
      <button class="btn p big" data-act="claim-export" ${c.ready&&!C.busy?'':'disabled'}>${ic('down',20)}${C.busy?'꺼내는 중…':`준비된 ${c.ready}건 폴더로 꺼내기`}</button></div>
     <div class="hint" style="margin-top:8px;font-size:12.5px">월 청구용 제출본이 정해진 환자의 보고서만, <b>이 PC의 새 폴더</b>에 내려받은 이름 그대로 꺼냅니다(누를 때마다 새 폴더). 공단 홈페이지의 파일 고르기에서 그 폴더를 열어 올리세요. <b>꺼냈다고 공단에 낸 것은 아닙니다.</b></div>
     ${o?`<div class="note ${o.skipped.length?'a':''}">${ic('check',15)} <b>${o.files}건</b>을 꺼냈습니다 → <span class="mono" style="word-break:break-all">${esc(o.folder)}</span>${o.skipped.length?`<details style="margin-top:6px"><summary>꺼내지 못한 것 ${o.skipped.length}건</summary><ul class="plain">${o.skipped.map(x=>`<li class="mono">${esc(x)}</li>`).join('')}</ul></details>`:''}${o.waiting?`<div class="hint" style="margin-top:4px">확인 필요로 남은 환자 ${o.waiting}명은 꺼내지 않았습니다.</div>`:''}</div>`:''}
     <div style="overflow:auto;margin-top:10px"><table class="grid"><thead><tr><th>차트번호</th><th>환자</th><th>상태</th><th>낼 파일 · 까닭</th><th></th></tr></thead><tbody>${rows.map(tr).join('')||'<tr><td colspan="5" class="hint">환자가 없습니다.</td></tr>'}</tbody></table></div>
     <div class="hint" style="margin-top:8px;font-size:12.5px">줄을 누르면 그 환자가 열립니다. '확인 필요'는 그 환자의 사용 보고서를 열어 용도(월 청구용)와 제출본을 정하면 '준비됨'이 됩니다.</div></div>`;
}
function vSoon(title,when){return `<h2>${title}</h2><div class="card empty" style="margin-top:12px">${ic('cal',36)}<div style="font-size:17px;font-weight:700;color:var(--ink);margin-top:6px">아직 만들지 않았습니다</div>${when}</div>`;}
/* ---------- 처음 켰을 때: 이 PC를 어떻게 쓸까요? ---------- */
const newWiz=()=>({step:'role',name:(S.setup&&S.setup.name)||'',dataRoot:(S.setup&&S.setup.suggestedDataRoot)||'',found:null,address:'',code:'',storeName:'',error:'',busy:false});
/* [폴더 고르기]: 윈도우의 폴더 창을 띄워 고른다(폴더 경로를 손으로 적지 않아도 되게). t 는 채울 칸, what 은 무엇을 고르는지. */
const pickBtn=(t,what,off)=>S.setup&&S.setup.canPick?`<button class="btn" data-act="pick-folder" data-t="${t}" data-what="${what}" ${off?'disabled':''}>${ic('folder',15)}폴더 고르기</button>`:'';
function vSetup(){
  const w=S.wiz;const err=w.error?`<div class="note a">${esc(w.error)}</div>`:'';
  if(w.step==='role') return `<div class="dlg wide" style="margin:6vh auto 0;box-shadow:var(--shadow)"><h2>이 PC를 어떻게 쓸까요?</h2><div class="hint">나중에 설정에서 바꿀 수 있습니다.</div>
     <div class="row" style="margin:16px 0;align-items:stretch"><button class="rolecard" data-act="wiz-go" data-step="store">${ic('folder',30)}<div style="font-size:19px;font-weight:800;margin:6px 0">보관 (서버)</div>서류를 <b>이 PC에</b> 보관합니다.<div class="hint" style="margin-top:6px">사무실에 한 대만. 켜져 있어야 다른 PC에서 볼 수 있습니다.</div></button>
      <button class="rolecard" data-act="wiz-go" data-step="find">${ic('pc',30)}<div style="font-size:19px;font-weight:800;margin:6px 0">연결 (클라이언트)</div>보관 PC의 서류를 <b>보고 넣습니다.</b><div class="hint" style="margin-top:6px">여러 대 가능. 이 PC에는 서류가 남지 않습니다.</div></button></div></div>`;
  if(w.step==='store') return `<div class="dlg" style="margin:6vh auto 0;box-shadow:var(--shadow)"><h2>보관 PC로 시작</h2>
     <div class="field" style="margin:14px 0"><label>서류함 이름</label><input data-w="name" value="${esc(w.name)}" maxlength="30" autocomplete="off">
      <label>자료 폴더</label><div><div class="row"><input data-w="dataRoot" value="${esc(w.dataRoot)}" class="mono" style="flex:1" autocomplete="off">${pickBtn('dataRoot','data',w.busy)}</div>
       ${w.pickNote?`<div class="hint" style="margin-top:4px;color:var(--accent2)">${esc(w.pickNote)}</div>`:''}<div class="hint" style="margin-top:4px">서류를 보관할 폴더입니다. ${S.setup&&S.setup.canPick?'[폴더 고르기]로 고르거나 직접 적어 주세요. ':''}빈 폴더나, 서류함 자료가 이미 든 폴더(PC 바꾸기 · 되살리기)여야 합니다. 없으면 만듭니다.</div></div></div>
     <div class="note">보관 PC는 켜져 있고 윈도우에 로그인돼 있어야 다른 PC에서 서류를 볼 수 있습니다. 서류함이 도는 동안에는 절전으로 들어가지 않습니다.</div>${err}
     ${w.askRebuild?`<div class="row" style="margin-top:8px"><button class="btn" data-act="setup-store" data-rebuild="1" ${w.busy?'disabled':''}>서류에서 목록을 다시 만들어 시작</button><span class="hint">서류 파일은 건드리지 않습니다.</span></div>`:''}
     <div class="row" style="margin-top:14px"><button class="btn" data-act="wiz-go" data-step="role">${ic('left',15)}뒤로</button><button class="btn" data-act="wiz-go" data-step="restore">백업에서 되살리기</button><span class="sp"></span><button class="btn p" data-act="setup-store" ${w.busy?'disabled':''}>보관으로 시작</button></div></div>`;
  if(w.step==='restore'){const sn=w.snaps;
    return `<div class="dlg" style="margin:6vh auto 0;box-shadow:var(--shadow)"><h2>백업에서 되살리기</h2><div class="hint">백업 폴더는 그대로 두고, 고른 시점의 서류함을 <b>새 자료 폴더</b>에 만듭니다.</div>
     <div class="field" style="margin:14px 0"><label>서류함 이름</label><input data-w="name" value="${esc(w.name)}" maxlength="30" autocomplete="off">
      <label>백업 폴더</label><div class="row"><input data-w="backupRoot" value="${esc(w.backupRoot||'')}" class="mono" style="flex:1" placeholder="예: E:\\서류함 백업" autocomplete="off">${pickBtn('backupRoot','restore',w.busy)}<button class="btn" data-act="restore-look" ${w.busy?'disabled':''}>살펴보기</button></div>
      ${sn?`<label>되살릴 시점</label><select data-w="snapshot">${sn.map((x,i)=>`<option value="${esc(x.name)}" ${x.name===w.snapshot?'selected':''}>${esc(dt(x.takenUtc))}${i?'':' (가장 최근)'} · 환자 ${x.patients}명 · 서류 ${x.docs}건</option>`).join('')}</select>
      <label>새 자료 폴더</label><div><div class="row"><input data-w="dataRoot" value="${esc(w.dataRoot)}" class="mono" style="flex:1" autocomplete="off">${pickBtn('dataRoot','data',w.busy)}</div>${w.pickNote?`<div class="hint" style="margin-top:4px;color:var(--accent2)">${esc(w.pickNote)}</div>`:''}<div class="hint" style="margin-top:4px">빈 폴더여야 합니다. 없으면 만듭니다.</div></div>`:''}</div>${err}
     <div class="row" style="margin-top:14px"><button class="btn" data-act="wiz-go" data-step="store">${ic('left',15)}뒤로</button><span class="sp"></span><button class="btn p" data-act="restore-start" ${sn&&!w.busy?'':'disabled'}>되살리기 시작</button></div></div>`;}
  if(w.step==='restoring'){const g=w.prog||{state:'running',done:0,total:0};const r=g.report;const box=h=>`<div class="dlg" style="margin:6vh auto 0;box-shadow:var(--shadow)">${h}</div>`;
    const plist=(title,list)=>list&&list.length?`<details style="margin-top:8px"><summary>${title} ${list.length}건</summary><ul class="plain">${list.slice(0,30).map(x=>`<li class="mono">${esc(x)}</li>`).join('')}</ul></details>`:'';
    if(g.state==='running')return box(`<h2>되살리는 중…</h2><div style="margin:14px 0;font-size:17px">서류 <b>${g.done}</b> / ${g.total||'?'}</div><div class="hint">서류마다 저장할 때의 확인값과 대조하며 옮깁니다. 창을 닫지 마세요.</div>`);
    if(g.state!=='done'||!r)return box(`<h2>되살리지 못했습니다</h2><div class="note a">${esc(g.error||'알 수 없는 까닭으로 멈췄습니다.')}</div><div class="hint">새 자료 폴더에 만들다 만 것이 남아 있을 수 있습니다. 다른 빈 폴더로 다시 해 주세요.</div><div class="row" style="margin-top:14px"><span class="sp"></span><button class="btn" data-act="wiz-go" data-step="restore">뒤로</button></div>`);
    return box(`<h2>되살렸습니다</h2><div class="note ${r.ok?'':'a'}">${r.ok?ic('check',15)+' 되살린 것 점검 통과 — 차이 0':ic('alert',15)+' 확인이 필요한 것이 있습니다'}</div>
     <dl class="kv" style="margin:12px 0"><dt>시점</dt><dd>${esc(dt(r.takenUtc))}</dd><dt>환자</dt><dd>${r.patients}명</dd><dt>서류</dt><dd>${r.docs}건 <span class="hint">· 지운 기록 ${r.tombstones}건</span></dd><dt>못 옮긴 서류</dt><dd>백업에 없음 ${r.missing} · 상함 ${r.damaged}</dd><dt>점검 차이</dt><dd>${r.differences}</dd></dl>
     ${plist('못 옮긴 것',r.problems)}${plist('점검 차이',r.differenceList)}
     <div class="hint" style="margin-top:8px">새 PC에서는 백업 폴더와 연결할 PC를 다시 정해야 합니다(설정 · 관리).</div>
     <div class="row" style="margin-top:14px"><span class="sp"></span><button class="btn p" data-act="restore-finish">서류함 시작</button></div>`);}
  if(w.step==='find') return `<div class="dlg" style="margin:6vh auto 0;box-shadow:var(--shadow)"><h2>서류함 찾기</h2><div class="hint">같은 사무실 안의 보관 PC를 찾습니다.</div>
     <div style="margin:14px 0">${w.found===null?'<div class="card hint" style="box-shadow:none">찾는 중…</div>':w.found.length?w.found.map(f=>`<div class="card" style="box-shadow:none;margin-bottom:8px"><div class="row">${ic('pc',26)}<div><b style="font-size:17px">${esc(f.name)}</b><div class="hint mono">${esc(f.address)}</div></div><span class="sp"></span><button class="btn p" data-act="pair-start" data-address="${esc(f.address)}" ${w.busy?'disabled':''}>연결</button></div></div>`).join(''):'<div class="card hint" style="box-shadow:none">찾지 못했습니다. 보관 PC가 켜져 있는지 확인하거나, 아래에 주소를 직접 넣어 주세요.</div>'}</div>
     <div class="row"><input data-w="address" value="${esc(w.address)}" placeholder="보관 PC 주소 (예: 192.168.0.10)" class="mono" style="flex:1" autocomplete="off"><button class="btn" data-act="pair-start" ${w.busy?'disabled':''}>이 주소로 연결</button></div>
     <div class="hint" style="margin-top:6px">주소는 보관 PC의 설정 · 관리 화면에 보입니다.</div>${err}
     <div class="row" style="margin-top:14px"><button class="btn" data-act="wiz-go" data-step="role">${ic('left',15)}뒤로</button><span class="sp"></span><button class="btn" data-act="wiz-go" data-step="find" ${w.busy?'disabled':''}>다시 찾기</button></div></div>`;
  return `<div class="dlg" style="margin:6vh auto 0;box-shadow:var(--shadow)"><h2>확인 숫자</h2><div>보관 PC <b>${esc(w.storeName)}</b> 화면에 같은 숫자가 떴는지 보고, <b>보관 PC에서 [허용]</b>을 눌러 주세요.</div>
     <div class="digits">${[...w.code].map(c=>`<span>${esc(c)}</span>`).join('')}</div><div class="hint" style="text-align:center">허용을 기다리는 중…</div>${err}
     <div class="row" style="margin-top:14px"><span class="sp"></span><button class="btn" data-act="wiz-go" data-step="find">취소</button></div></div>`;
}
/* 역할이 바뀌면 프로그램이 스스로 다시 켜진다 → 다시 이어질 때까지 기다렸다가 화면을 새로 연다. */
async function waitRestart(oldRole){
  S.restarting=true;render();
  for(let i=0;i<60;i++){await new Promise(r=>setTimeout(r,700));try{const r=await fetch('/api/health',{cache:'no-store'});const h=await r.json();if(h.role!==oldRole){location.reload();return;}}catch(e){}}
  S.restarting=false;toast('다시 켜지지 않았습니다. 프로그램을 끝내고 다시 실행해 주세요.');render();
}
let pairTimer=null;
function pollPair(){
  clearInterval(pairTimer);
  pairTimer=setInterval(async()=>{
    if(!S.wiz||S.wiz.step!=='code'){clearInterval(pairTimer);return;}
    const r=await api('/api/setup/pair/poll');const st=r.body.state;
    if(st==='allowed'){clearInterval(pairTimer);waitRestart('');}
    else if(st==='denied'||st==='gone'||st==='none'){clearInterval(pairTimer);S.wiz.step='find';S.wiz.error=st==='denied'?'보관 PC에서 거절했습니다.':'시간이 지나 청이 사라졌습니다. 다시 연결해 주세요.';render();}
  },1500);
}

/* ---------- 설정 · 관리 ---------- */
const LINK_MSG={store_offline:'보관 PC와 이어지지 않습니다. 보관 PC가 켜져 있는지 확인해 주세요.',store_changed:'보관 PC가 연결할 때의 그 PC가 아닙니다. 보관 PC를 바꿨다면 설정에서 다시 연결해 주세요.',unpaired:'보관 PC에서 이 PC의 연결이 해제되었습니다. 설정에서 다시 연결해 주세요.'};
function vAdmin(){
  const u=S.setup||{};const store=u.role==='store';const ST={online:['이어짐','g'],offline:['꺼져 있음','r'],changed:['다른 PC임','r'],unpaired:['연결 해제됨','r']};
  const role=`<div class="card"><h3>이 PC의 역할</h3><div class="row"><span class="chip ${store?'g':'b'}" style="font-size:14px">${store?'보관 (서버)':'연결 (클라이언트)'}</span><b>${esc(u.name)}</b></div>
     <dl class="kv" style="margin-top:12px">${store?`<dt>자료 폴더</dt><dd class="mono" style="word-break:break-all">${esc(u.dataRoot)}</dd><dt>다른 PC 받기</dt><dd>${u.lanPort?`켜짐 · 포트 <span class="mono">${u.lanPort}</span>`:'꺼짐 (이 PC에서만 씀)'}</dd>${u.lanPort&&(u.addresses||[]).length?`<dt>이 PC 주소</dt><dd class="mono">${u.addresses.map(esc).join(' · ')}</dd>`:''}`:`<dt>보관 PC</dt><dd><b>${esc(u.store.name)}</b> ${chip(...(ST[u.store.state]||['?','']))}</dd><dt>주소</dt><dd class="mono">${esc(u.store.address)}</dd>`}</dl>
     ${u.canChange?`<div class="row" style="margin-top:12px"><button class="btn" data-act="reset-ask">역할 다시 고르기</button><span class="hint">자료 폴더와 서류는 그대로 둡니다.</span></div>`:'<div class="hint" style="margin-top:10px">시험용으로 켠 상태라 여기서 역할을 바꿀 수 없습니다.</div>'}</div>`;
  const devs=store?`<div class="card"><h3>연결된 PC <span class="hint">${(u.devices||[]).length}대</span></h3>
     ${(u.devices||[]).length?`<table class="grid"><tbody>${u.devices.map(d=>`<tr><td>${ic('pc')} <b>${esc(d.name)}</b></td><td class="hint">연결한 날 ${esc(new Date(d.pairedUtc).toLocaleDateString('ko-KR'))}</td><td style="text-align:right"><button class="btn s danger" data-act="revoke-ask" data-id="${esc(d.id)}" data-name="${esc(d.name)}">해제</button></td></tr>`).join('')}</tbody></table>`:'<div class="hint">아직 연결된 PC가 없습니다.</div>'}
     <div class="hint" style="margin-top:8px">${u.lanPort?'다른 PC에서 서류보관함을 켜고 [연결] → [서류함 찾기]를 누르면, 여기에 확인 숫자가 뜹니다. 숫자가 같으면 [허용]하세요. 못 찾으면 위에 적힌 이 PC 주소를 그 PC에 직접 넣습니다. 윈도우 방화벽이 물으면 [허용]을 눌러야 다른 PC가 들어올 수 있습니다.':'이 실행에서는 다른 PC를 받지 않습니다.'}</div></div>`:'';
  return `<h2>설정 · 관리</h2><div class="setgrid" style="margin-top:12px">${role}${devs}${vUpdate()}${store?vKeep():''}
    <div class="card"><h3>아직 만들지 않은 것</h3><div class="hint">서류 종류 고치기는 다음에 붙입니다.${store?'':' 백업 · 휴지통 · 한 일 기록은 보관 PC의 이 화면에서 봅니다.'}</div></div></div>`;
}
/* 프로그램 판 · 자동 업데이트(이 PC의 것). 새 판은 저절로 받아 두었다가, 프로그램을 쓰지 않을 때나 다음에 켤 때 바뀐다. */
function vUpdate(){
  const u=S.setup||{},up=u.update,busy=S.upBusy;
  if(!up)return `<div class="card"><h3>프로그램 판 <span class="hint">${esc(u.version||'')}</span></h3><div class="hint">설치 파일로 설치한 프로그램만 새 판을 스스로 받습니다. (지금은 시험용으로 켠 상태입니다.)</div></div>`;
  let line;
  if(up.ready)line=`<div class="note">새 판 <b>${esc(up.ready)}</b> 을 받아 두었습니다. 프로그램을 쓰지 않을 때나 다음에 켤 때 저절로 바뀝니다(몇 초 동안 꺼졌다 켜집니다).${up.notes?`<br><span class="hint">${esc(up.notes)}</span>`:''}</div>`;
  else if(up.failedVersion)line=`<div class="note a">${ic('alert',15)} 새 판 ${esc(up.failedVersion)} 으로 바꾸지 못했습니다. ${esc(up.failedWhy)}</div>`;
  else if(up.result==='error'||up.result==='refused')line=`<div class="note a">${ic('alert',15)} ${esc(up.message)}</div>`;
  else if(up.result==='latest')line=`<div class="hint">지금 판이 가장 새 판입니다.</div>`;
  else line=`<div class="hint">아직 새 판을 확인하지 않았습니다. 켜고 조금 뒤에 스스로 확인합니다.</div>`;
  return `<div class="card"><h3>프로그램 판 <span class="hint">${esc(u.version)}${up.checkedUtc?' · 확인한 때 '+esc(dt(up.checkedUtc)):''}</span></h3>${line}
    <div class="row" style="margin-top:10px">${up.ready&&up.canApply?`<button class="btn p" data-act="update-apply" ${busy?'disabled':''}>지금 바꾸기</button>`:''}<button class="btn" data-act="update-check" ${busy?'disabled':''}>${busy==='check'?'확인하는 중…':up.failedVersion?'다시 해 보기':'지금 확인'}</button><span class="rowst ${S.upMsg&&S.upMsg.ok?'ok':'err'}">${esc(S.upMsg?S.upMsg.t:'')}</span></div>
    <div class="row" style="margin-top:12px"><label class="row" style="gap:8px;cursor:pointer"><input type="checkbox" data-act="update-auto" ${up.auto?'checked':''} ${up.canChange?'':'disabled'}> <b>새 판이 나오면 저절로 받아서 바꾸기</b></label><span class="hint" style="font-size:12.5px">끄면 [지금 확인]과 [지금 바꾸기]를 직접 눌러야 합니다.</span></div>
    ${up.lastFrom&&up.lastAppliedUtc?`<div class="hint" style="margin-top:8px">${esc(dt(up.lastAppliedUtc))}에 ${esc(up.lastFrom)} 판에서 지금 판으로 바뀌었습니다.</div>`:''}</div>`;
}
const ACT={roster_sync:'명단 맞추기',export:'청구 서류 꺼내기',batch_takeback:'묶음 되돌리기',autostart:'자동 시작',upload:'넣기',edit:'고치기',move:'옮기기',delete:'휴지통',undelete:'휴지통에서 되살림',patient_create:'환자 등록',patient_update:'환자 고치기',upload_refused:'넣기 거절',move_refused:'옮기기 거절',backup_settings:'백업 설정',check:'점검',restore:'백업에서 되살림'};
function vKeep(){
  const a=S.admin;if(!a)return '<div class="card hint">불러오는 중…</div>';const b=a.backup,st=b.state,f=S.bform,off=a.canChange?'':'disabled';
  const plist=(title,list)=>list&&list.length?`<details style="margin-top:8px"><summary>${title} ${list.length}건</summary><ul class="plain">${list.slice(0,20).map(x=>`<li class="mono">${esc(x)}</li>`).join('')}</ul></details>`:'';
  const backup=`<div class="card"><h3>백업 <span class="hint">${b.configured?(st.lastSuccessUtc?'마지막 '+esc(dt(st.lastSuccessUtc)):'아직 한 번도 안 됨'):'꺼짐'}</span></h3>
    ${[...a.warnings,...a.host].map(w=>`<div class="note a">${ic('alert',15)} ${esc(w)}</div>`).join('')}
    <div class="field" style="margin-top:10px"><label>백업 폴더</label><div class="row"><input data-b="root" class="mono" style="flex:1" value="${esc(f.root)}" placeholder="예: E:\\서류함 백업   또는   \\\\PC이름\\폴더" autocomplete="off" ${off}>${pickBtn('broot','backup',!a.canChange)}</div>
      <label>백업 시각</label><div class="row"><input type="time" data-b="at" value="${esc(f.at)}" style="width:130px" ${off}><span class="hint" style="font-size:12.5px">그 시각에 꺼져 있었으면 켜진 뒤에 합니다.</span></div></div>
    <div class="row" style="margin-top:10px"><button class="btn" data-act="backup-save" ${a.canChange&&!b.running?'':'disabled'}>저장</button><button class="btn p" data-act="backup-run" ${b.configured&&!b.running?'':'disabled'}>${b.running?'백업하는 중…':'지금 백업'}</button><span class="rowst ${S.bmsg&&S.bmsg.ok?'ok':'err'}">${esc(S.bmsg?S.bmsg.t:'')}</span></div>
    ${st.lastRunUtc?`<dl class="kv" style="margin-top:12px;font-size:13px"><dt>마지막 실행</dt><dd>${esc(dt(st.lastRunUtc))} — ${esc(st.lastResult)}</dd><dt>목록 사본</dt><dd>${b.snapshots}개 <span class="hint">(30개까지 둡니다)</span></dd><dt>돌아가며 점검</dt><dd>보관 PC ${st.scrubChecked}건 · 백업 디스크 ${st.backupChecked}건</dd></dl>`:''}
    ${plist('백업 문제',st.problemList)}${plist('서류 점검(보관 PC)',st.scrubProblemList)}${plist('백업 디스크 점검',st.backupProblemList)}
    ${a.autoStart&&a.autoStart.supported?`<div class="row" style="margin-top:12px"><label class="row" style="gap:8px;cursor:pointer"><input type="checkbox" data-act="autostart" ${a.autoStart.on?'checked':''}> <b>윈도우를 켤 때 서류보관함을 자동으로 시작</b></label><span class="hint" style="font-size:12.5px">보관 PC는 켜 두기를 권합니다(꺼져 있으면 백업도, 다른 PC에서 보기도 안 됩니다).</span></div>`:''}
    <div class="hint" style="margin-top:10px;font-size:12.5px">백업 폴더는 <b>다른 디스크</b>(외장 디스크 · 다른 PC의 공유 폴더)에 두세요. 백업에서는 아무것도 지우지 않습니다. 되살리기는 새 PC에서 서류보관함을 처음 켤 때 [보관] → [백업에서 되살리기]로 합니다.</div>
    <div class="row wrap" style="margin-top:10px"><span class="hint">복원 연습 한 날</span><input type="date" data-b="drill" value="${esc(f.drill)}"><button class="btn s" data-act="drill-save">적기</button><span class="hint" style="font-size:12px">실제 서류를 넣기 전에 한 번, 그 뒤 반년에 한 번.</span></div></div>`;
  const c=S.check;
  const check=`<div class="card"><h3>비상용 목록 · 점검</h3>
    <div>자료 폴더의 <b class="mono">서류목록.html</b> <span class="hint">${a.list.listUtc?esc(dt(a.list.listUtc))+' 기준':'아직 없음'}</span><div class="hint" style="font-size:12.5px;margin-top:2px">프로그램이 켜지지 않을 때 아무 브라우저로나 열어 서류를 찾는 한 장입니다. 백업할 때마다 새로 만들고 백업 폴더에도 들어갑니다.</div></div>
    <div class="row" style="margin-top:8px"><button class="btn" data-act="list-make">지금 만들기</button></div>
    <div style="margin-top:14px">목록(DB)과 실제 파일·표식을 견줍니다. <b>차이 0 이 통과</b>입니다.</div>
    <div class="row" style="margin-top:8px"><button class="btn" data-act="check-run" data-full="" ${S.checking?'disabled':''}>빠른 점검</button><button class="btn" data-act="check-run" data-full="1" ${S.checking?'disabled':''}>내용까지 점검</button>${S.checking?'<span class="hint">점검하는 중…</span>':''}</div>
    ${c?`<div class="note ${c.ok?'':'a'}">${c.ok?ic('check',15)+' 통과':ic('alert',15)+' 확인 필요'} — 서류 ${c.docs}건 · 지운 기록 ${c.deleted}건 · 차이 ${c.counts.differences} · 원본 없음 ${c.counts.missing}${c.full?` · 상함 ${c.counts.damaged}`:''} <span class="hint">(${esc(dt(c.atUtc))}${c.full?', 내용까지':''})</span></div>${plist('차이',c.differences)}${plist('원본 없음',c.missing)}${plist('상함',c.damaged)}`:''}
    ${a.canRead?'':`<div class="note a">${ic('alert',15)} 이 PC에는 한국어 글자 읽기가 없어 <b>종류 자동 채우기가 꺼져 있습니다.</b> 윈도우 설정 → 시간 및 언어 → 언어에서 한국어(광학 문자 인식)를 더하면 켜집니다.</div>`}
    ${a.restored?`<div class="note ${a.restored.ok?'':'a'}">이 자료는 <b>${esc(dt(a.restored.takenUtc))}</b> 백업 시점에서 되살린 것입니다. 되살린 것 점검: 차이 ${a.restored.differences} · 못 옮긴 서류 ${a.restored.missing+a.restored.damaged}</div>`:''}</div>`;
  const trash=`<div class="card" style="grid-column:span 2"><h3>휴지통 <span class="hint">${a.trash}건</span></h3>
    ${S.trash?(S.trash.length?`<div style="max-height:300px;overflow:auto"><table class="grid"><thead><tr><th>지운 때</th><th>환자</th><th>서류</th><th>파일 이름</th><th></th></tr></thead><tbody>${S.trash.map(t=>`<tr><td class="hint" style="white-space:nowrap">${esc(dt(t.deletedUtc))} · ${esc(t.deletedBy)}</td><td>${t.patient?`<b>${esc(t.patient.name)}</b> <span class="mono hint">${esc(t.patient.chartNo)}</span>`:'<span class="hint">—</span>'}</td><td>${esc(t.typeName)||'<span class="hint">(파일 없음)</span>'} <span class="hint">${esc(t.month||t.docDate)}</span></td><td class="mono hint" style="font-size:12px;word-break:break-all">${esc(t.fileName)}</td><td style="text-align:right"><button class="btn s" data-act="trash-restore" data-id="${t.id}" ${t.canRestore?'':'disabled'}>되살리기</button></td></tr>`).join('')}</tbody></table></div>`:'<div class="hint">비어 있습니다.</div>'):`<button class="btn" data-act="trash-load" ${a.trash?'':'disabled'}>휴지통 보기</button>`}
    <div class="hint" style="margin-top:8px;font-size:12.5px">지운 서류는 파일을 지우지 않고 자료 폴더의 trash 폴더에 둡니다. 되살리면 원래 환자의 서류로 돌아갑니다.</div></div>`;
  const audit=`<div class="card" style="grid-column:span 2"><h3>한 일 기록 <span class="hint">${S.audit?esc(S.audit.month)+' · 최근 '+S.audit.lines.length+'줄':''}</span></h3>
    ${S.audit?(S.audit.lines.length?`<div style="max-height:320px;overflow:auto"><table class="grid"><thead><tr><th>때</th><th>PC · 로그인</th><th>한 일</th><th>서류함 번호</th><th>서류</th><th>메모</th></tr></thead><tbody>${S.audit.lines.map(l=>`<tr><td class="hint" style="white-space:nowrap">${esc(dt(l.at))}</td><td>${esc(l.station)} <span class="hint">${esc(l.user)}</span></td><td>${esc(ACT[l.act]||l.act)}</td><td class="mono">${l.box||''}</td><td class="mono hint">${esc((l.doc||'').slice(0,8))}</td><td class="hint">${esc(l.note)}</td></tr>`).join('')}</tbody></table></div>`:'<div class="hint">이번 달 기록이 없습니다.</div>'):`<button class="btn" data-act="audit-load">기록 보기</button>`}
    <div class="hint" style="margin-top:8px;font-size:12.5px">누가(PC와 윈도우 로그인 이름) 무엇을 했는지 남습니다. 환자 이름은 적지 않습니다.</div></div>`;
  return backup+check+trash+audit;
}
let bkTimer=null;
function watchBackup(){clearInterval(bkTimer);bkTimer=setInterval(async()=>{await loadAdmin();if(!S.admin||!S.admin.backup.running){clearInterval(bkTimer);await loadStatus();}if(S.scene==='admin'&&!S.modal){S.keep=true;render();}},1500);}
let rsTimer=null;
function pollRestore(){clearInterval(rsTimer);rsTimer=setInterval(async()=>{const w=S.wiz;if(!w||w.step!=='restoring'){clearInterval(rsTimer);return;}
  const r=await api('/api/setup/restore/progress');if(!r.ok)return;w.prog=r.body;if(r.body.state!=='running')clearInterval(rsTimer);render();},700);}

/* ---------- 틀 ---------- */
function shell(inner){
  const r=(s,i,l)=>`<button data-act="scene" data-s="${s}" class="${S.scene===s?'on':''}">${ic(i,24)}<span>${l}</span></button>`;
  const heldN=S.up.length+S.held.length+Object.values(S.pend).reduce((a,x)=>a+x.n,0);const st=S.status,u=S.setup;
  const setup=S.scene==='setup';const connect=u&&u.role==='connect';
  const chips=!u?'':connect?`<span class="chip ${S.link?'r':'g'}">${ic('pc',14)}보관 PC · ${esc(u.store.name)}</span><span class="chip">이 PC · ${esc(u.name)} (연결)</span>`
    :u.role==='store'?`<span class="chip g">${ic('pc',14)}${esc(u.name)} · 보관</span>`:'';
  return `<div class="app">${S.online?'':'<div class="offline">서류함 프로그램과 이어지지 않습니다. 프로그램이 켜져 있는지 확인해 주세요.</div>'}${S.online&&S.link?`<div class="offline">${LINK_MSG[S.link]}</div>`:''}
   <div class="top"><div class="brand">${ic('folder',22)}숨길이 서류보관함</div><span class="sp"></span>
     ${heldN?`<span class="chip a">${ic('alert',14)}넣다 만 줄 ${heldN}</span>`:''}${chips}</div>
   <div class="body">${setup?'':`<div class="rail">${r('patient','user','환자')}${r('usage','report','사용 보고서')}${r('claim','cal','이번 달 청구')}<span style="flex:1"></span>${r('admin','gear','설정·관리')}</div>`}
     <div class="main">${inner}</div></div>
   <div class="status"><span><i class="dot ${S.online&&!S.link?'':'r'}"></i>${!S.online?'끊김':S.link?'보관 PC와 끊김':connect?'보관 PC와 이어짐':'서류함 프로그램과 이어짐'}</span>${st&&!setup?`<span>환자 ${st.patients}명 · 서류 ${st.docs}건</span>`:''}${st&&!setup&&st.warnings&&st.warnings.length?`<span class="warnst" data-act="scene" data-s="admin" title="${esc(st.warnings.join(' / '))}">${ic('alert',13)} ${esc(st.warnings[0])}${st.warnings.length>1?` 외 ${st.warnings.length-1}건`:''}</span>`:(st&&!setup&&st.backup&&st.backup.lastSuccessUtc?`<span>백업 ${esc(dt(st.backup.lastSuccessUtc))}</span>`:'')}<span class="sp"></span>${u&&u.update&&u.update.ready&&!setup?`<span class="warnst" data-act="scene" data-s="admin" title="프로그램을 쓰지 않을 때나 다음에 켤 때 저절로 바뀝니다">새 판 ${esc(u.update.ready)} 받아 둠</span>`:''}<span>판 ${u?esc(u.version):''}</span></div>
   ${S.restarting?'<div class="shade"><div class="dlg" style="max-width:380px;text-align:center"><h2>다시 켜는 중…</h2><div class="hint">잠시만 기다려 주세요.</div></div></div>':''}</div>`;
}
/* 지금 보고 있는 곳(같은 화면 · 같은 환자)이 그대로면 다시 그려도 스크롤 자리를 지킨다 — 서류를 열어 보고 닫거나 고쳐 저장한 뒤에도 보던 줄에 머문다.
   다른 화면 · 다른 환자 · 처음 설정의 다음 걸음으로 넘어갈 때만 맨 위에서 시작한다. 열려 있는 창(크게 보기 등) 안의 스크롤도 같은 창이면 지킨다. */
function pageKey(){const s=S.scene;return s+'|'+(s==='patient'?S.pid||'':s==='usage'?(S.batch?S.batch.id:''):s==='claim'?(S.claim?S.claim.month:''):s==='setup'?(S.wiz?S.wiz.step:''):'');}
function modalKey(){const m=S.modal;return m?m.k+'|'+(m.id==null?'':m.id):'';}
let lastPage=null,lastModal='';
function render(){
  const v={patient:vPatient,usage:vUsage,claim:vClaim,admin:vAdmin,setup:vSetup}[S.scene]();
  const main=document.querySelector('.main');const y=main?main.scrollTop:0;const pl=document.querySelector('.prows');const ly=pl?pl.scrollTop:0;
  const page=pageKey(),stay=S.keep||page===lastPage;lastPage=page;S.keep=false;
  const mkey=modalKey(),inDlg=mkey&&mkey===lastModal?['.dlg','.pick'].map(q=>{const el=document.querySelector('#modal '+q);return el?el.scrollTop:0;}):null;lastModal=mkey;
  const act=document.activeElement,focusF=act&&act.dataset?act.dataset.f:null,focusW=act&&act.dataset?act.dataset.w:null,focusB=act&&act.dataset?act.dataset.b:null;
  let caret=null;try{if((focusF||focusW||focusB)&&act.selectionStart!=null)caret=act.selectionStart;}catch(e){}
  document.getElementById('app').innerHTML=shell(v);
  if(stay)document.querySelector('.main').scrollTop=y;
  const pl2=document.querySelector('.prows');if(pl2)pl2.scrollTop=ly;S.flash=false;
  document.getElementById('modal').innerHTML=vModal();
  if(inDlg)['.dlg','.pick'].forEach((q,i)=>{const el=document.querySelector('#modal '+q);if(el&&inDlg[i])el.scrollTop=inDlg[i];});
  const again=focusF?document.querySelector(`#modal [data-f="${focusF}"]`):focusW?document.querySelector(`[data-w="${focusW}"]`):focusB?document.querySelector(`[data-b="${focusB}"]`):null;
  if(again){again.focus();if(caret!=null&&again.setSelectionRange)try{again.setSelectionRange(caret,caret);}catch(e){}}
}
let tt;function toast(t){const el=document.getElementById('toast');el.innerHTML=`<div class="toast">${t}</div>`;clearTimeout(tt);tt=setTimeout(()=>el.innerHTML='',5200);}

/* ---------- 동작 ---------- */
const A={
 async scene(d){if(S.saving||(S.batch&&S.batch.busy)){toast('저장이 끝난 뒤에 바꿉니다.');return;}S.scene=d.s;if(d.s==='admin'){await loadSetup();await loadAdmin();}if(d.s==='claim'){if(S.claim)S.claim.out=null;await loadClaim();}},
 'batch-pick'(){const el=document.getElementById('bfiles');if(el)el.click();return false;},
 'batch-ok'(d,e){const r=S.batch.rows[+d.i];if(r)r.ok=e.target.checked;S.keep=true;},
 'batch-del'(d){S.batch.rows.splice(+d.i,1);S.keep=true;},
 'batch-save'(){saveBatch();return false;},
 'batch-new'(){S.batch=newBatch();},
 async 'batch-undo'(){const B=S.batch;const r=await api('/api/batch/takeback',jsonBody({body:{batch:B.id}}));
   if(!r.ok){toast(esc(r.body.error||'되돌리지 못했습니다.'));return;}
   await Promise.all([loadPatients(),loadStatus()]);S.batch=newBatch();toast(`이 묶음 ${r.body.data.count}건을 휴지통으로 되돌렸습니다.`);},
 async 'claim-move'(d){const C=S.claim;const [y,m]=C.month.split('-').map(Number);C.month=ym(new Date(y,m-1+(+d.d),1));C.out=null;await loadClaim();},
 async 'claim-export'(){const C=S.claim;C.busy=true;render();const r=await api('/api/export/claims',jsonBody({body:{month:C.month}}));C.busy=false;
   if(!r.ok){toast(esc(r.body.error||'꺼내지 못했습니다.'));return;}C.out=r.body;await loadClaim();},
 async 'backup-save'(){const f=S.bform;const r=await api('/api/admin/backup/settings',jsonBody({body:{root:f.root,at:f.at}}));
   S.bmsg=r.ok?{ok:true,t:f.root.trim()?'저장했습니다.':'백업을 껐습니다.'}:{ok:false,t:r.body.error||'저장하지 못했습니다.'};if(r.ok){f.root=r.body.root;f.at=r.body.at;}
   await Promise.all([loadAdmin(),loadStatus()]);S.keep=true;},
 async 'backup-run'(){const r=await api('/api/admin/backup/run',jsonBody({body:{}}));S.keep=true;
   if(!r.ok){S.bmsg={ok:false,t:r.body.error||'시작하지 못했습니다.'};return;}S.bmsg=null;await loadAdmin();watchBackup();},
 async autostart(d,e){const on=e.target.checked;const r=await api('/api/admin/autostart',jsonBody({body:{on}}));await loadAdmin();S.keep=true;
   toast(r.ok?(r.body.on?'윈도우를 켤 때 자동으로 시작합니다.':'자동 시작을 껐습니다.'):esc(r.body.error||'바꾸지 못했습니다.'));},
 async 'drill-save'(){const r=await api('/api/admin/drill',jsonBody({body:{day:S.bform.drill}}));S.keep=true;toast(r.ok?'복원 연습 한 날을 적었습니다.':esc(r.body.error||'적지 못했습니다.'));},
 async 'list-make'(){const r=await api('/api/admin/list',jsonBody({body:{}}));await loadAdmin();S.keep=true;toast(r.ok?'비상용 목록을 새로 만들었습니다.':esc(r.body.error||'만들지 못했습니다.'));},
 async 'check-run'(d){S.checking=true;S.keep=true;render();const r=await api('/api/admin/check',jsonBody({body:{full:!!d.full}}));S.checking=false;S.keep=true;
   if(r.ok)S.check=r.body;else toast(esc(r.body.error||'점검하지 못했습니다.'));},
 async 'trash-load'(){const r=await api('/api/admin/trash');if(r.ok)S.trash=r.body.items;S.keep=true;},
 async 'trash-restore'(d){const r=await api(`/api/admin/trash/${d.id}/restore`,jsonBody({body:{}}));S.keep=true;
   if(!r.ok){toast(esc(r.body.error||'되살리지 못했습니다.'));return;}
   await A['trash-load']();await Promise.all([loadAdmin(),loadPatients(),loadDocs(),loadStatus()]);toast('되살렸습니다. 원래 환자의 서류로 돌아갔습니다.');},
 async 'audit-load'(){const r=await api('/api/admin/audit');if(r.ok)S.audit=r.body;S.keep=true;},
 async 'restore-look'(){const w=S.wiz;w.busy=true;w.error='';render();const r=await api('/api/setup/restore/look',jsonBody({body:{backupRoot:w.backupRoot||''}}));w.busy=false;
   if(!r.ok){w.snaps=null;w.error=r.body.error||'살펴보지 못했습니다.';return;}w.snaps=r.body.snapshots;w.snapshot=w.snaps[0].name;},
 async 'restore-start'(){const w=S.wiz;w.busy=true;w.error='';render();
   const r=await api('/api/setup/restore/start',jsonBody({body:{name:w.name,backupRoot:w.backupRoot,snapshot:w.snapshot,dataRoot:w.dataRoot}}));w.busy=false;
   if(!r.ok){w.error=r.body.error||'시작하지 못했습니다.';return;}w.step='restoring';w.prog=null;pollRestore();},
 async 'restore-finish'(){const r=await api('/api/setup/restore/finish',jsonBody({body:{}}));if(r.ok){waitRestart('');return false;}toast(esc(r.body.error||'시작하지 못했습니다.'));},
 async 'wiz-go'(d){const w=S.wiz;w.step=d.step;w.error='';w.pickNote='';clearInterval(pairTimer);
   if(d.step==='find'){w.found=null;render();const r=await api('/api/setup/find',{method:'POST'});w.found=r.ok?r.body.found:[];}},
 async 'setup-store'(d){const w=S.wiz;w.busy=true;w.error='';render();
   const r=await api('/api/setup/store',jsonBody({body:{name:w.name,dataRoot:w.dataRoot,rebuild:!!d.rebuild}}));w.busy=false;
   if(!r.ok){w.error=r.body.error||'시작하지 못했습니다.';w.askRebuild=r.body.code==='no_db';
     if(r.body.code==='backup_folder'){w.backupRoot=w.dataRoot;w.dataRoot=(S.setup&&S.setup.suggestedDataRoot)||'';w.snaps=null;w.step='restore';}
     return;}
   waitRestart('');return false;},
 async 'pair-start'(d){const w=S.wiz;const address=d.address||w.address;w.busy=true;w.error='';render();
   const r=await api('/api/setup/pair/start',jsonBody({body:{address}}));w.busy=false;
   if(!r.ok){w.error=r.body.error||'연결하지 못했습니다.';return;}
   w.code=r.body.code;w.storeName=r.body.storeName;w.step='code';pollPair();},
 async 'pair-allow'(){const m=S.modal;const r=await api('/api/setup/pair/allow',jsonBody({body:{id:m.req.id}}));
   if(!r.ok){m.error=r.body.error||'허용하지 못했습니다.';return;}
   S.modal=null;await loadSetup();toast(`'${esc(m.req.name)}'를 연결했습니다.`);},
 /* 윈도우의 폴더 창에서 고른 폴더를 칸에 채운다. 자료 폴더로 '다른 파일이 든 폴더'를 고르면 그 안에 새 폴더를 만들어 쓰게 이끈다(빈 폴더여야 하므로). */
 async 'pick-folder'(d){
   const w=S.wiz,admin=d.t==='broot';const cur=admin?(S.bform&&S.bform.root):(w&&w[d.t]);
   const r=await api('/api/setup/pick',jsonBody({body:{what:d.what,start:cur||''}}));S.keep=true;
   if(!r.ok){toast(esc((r.body&&r.body.error)||'폴더 창을 띄우지 못했습니다.'));return;}
   const f=r.body.folder,st=r.body.state;if(!f)return;   /* 그만둠 */
   if(admin){if(S.bform)S.bform.root=f;S.bmsg=null;return;}
   if(!w)return;w.error='';w.pickNote='';w.askRebuild=false;
   if(d.t==='backupRoot'){w.backupRoot=f;w.snaps=null;if(st==='backup')return A['restore-look']();w.error='고른 폴더에 서류함 백업이 없습니다. 백업을 둔 폴더(안에 db · files 폴더가 있습니다)를 골라 주세요.';return;}
   if(st==='backup'&&w.step==='store'){w.backupRoot=f;w.dataRoot=(S.setup&&S.setup.suggestedDataRoot)||'';w.snaps=null;w.step='restore';toast('고른 폴더는 백업 폴더입니다. 백업에서 되살리기로 넘어갑니다.');return A['restore-look']();}
   if(st==='other'||(st!=='empty'&&w.step==='restore')){w.dataRoot=f.replace(/[\\/]+$/,'')+'\\서류함 자료';w.pickNote='고른 폴더에 다른 파일이 있어, 그 안에 [서류함 자료] 폴더를 새로 만들어 씁니다.';return;}
   w.dataRoot=f;if(st==='docbox')w.pickNote='서류함 자료가 든 폴더입니다. 그 자료로 이어서 시작합니다.';},
 async 'update-check'(){S.upBusy='check';S.upMsg=null;S.keep=true;render();const r=await api('/api/setup/update/check',{method:'POST'});S.upBusy='';
   if(r.ok&&S.setup){S.setup.update=r.body.update;const up=r.body.update;if(up.result==='latest')S.upMsg={ok:true,t:'확인했습니다.'};}else S.upMsg={ok:false,t:(r.body&&r.body.error)||'확인하지 못했습니다.'};S.keep=true;},
 async 'update-apply'(){S.upBusy='apply';S.upMsg=null;S.keep=true;render();const r=await api('/api/setup/update/apply',{method:'POST'});
   if(r.ok){S.restarting=true;render();setTimeout(()=>location.reload(),90000);return false;}   /* 프로그램이 꺼졌다 켜지면 이 화면도 새로 뜬다 */
   S.upBusy='';S.upMsg={ok:false,t:(r.body&&r.body.error)||'바꾸지 못했습니다.'};await loadSetup();S.keep=true;},
 async 'update-auto'(d,e){const r=await api('/api/setup/update/auto',jsonBody({body:{on:e.target.checked}}));if(r.ok&&S.setup)S.setup.update=r.body.update;else toast(esc((r.body&&r.body.error)||'바꾸지 못했습니다.'));S.keep=true;},
 async 'pair-deny'(){const m=S.modal;await api('/api/setup/pair/deny',jsonBody({body:{id:m.req.id}}));S.modal=null;await loadSetup();toast('거절했습니다.');},
 'reset-ask'(){S.modal={k:'reset'};},
 async 'reset-ok'(){const old=S.setup.role;S.modal=null;const r=await api('/api/setup/reset',jsonBody({body:{}}));if(r.ok){waitRestart(old);return false;}toast(esc(r.body.error||'바꾸지 못했습니다.'));},
 'revoke-ask'(d){S.modal={k:'revoke',id:d.id,name:d.name};},
 async 'revoke-ok'(){const m=S.modal;const r=await api('/api/setup/devices/revoke',jsonBody({body:{id:m.id}}));
   if(!r.ok){m.error=r.body.error||'해제하지 못했습니다.';return;}
   S.modal=null;await loadSetup();toast(`'${esc(m.name)}'의 연결을 해제했습니다.`);},
 async open(d){S.scene='patient';S.keep=true;await sel(+d.id);},
 lf(d){S.lf=d.k;S.keep=true;},ls(){S.ls=S.ls==='no'?'todo':'no';S.snap=null;S.keep=true;},
 tab(d){S.tab=d.t;S.keep=true;},
 'pick-files'(){const el=document.getElementById('files');if(el)el.click();return false;},
 'up-del'(d){dropRow(S.up.splice(+d.i,1)[0]);S.keep=true;},
 'pick-type'(d){const u=S.up[+d.i];if(!u)return;u.type=d.t;u.typeFrom='후보에서 고름';u.touched=true;u.cands=null;u.use=u.type==='usage'?(u.month?'claim':'unknown'):'';S.keep=true;},
 'hint-stage'(d){const u=S.up[+d.i];u.stage=u.stageHint;u.stageHint='';S.keep=true;},
 'held-ok'(d){const h=S.held.splice(+d.i,1)[0];h.confirm=true;h.state='';h.why='';if(!h.type)h.type='';S.up.push(h);S.keep=true;toast('확인했습니다. 올리기 줄로 옮겼습니다. 저장하면 확인한 일이 기록에 남습니다.');},
 'held-del'(d){dropRow(S.held.splice(+d.i,1)[0]);S.keep=true;},
 save(){saveAll();return false;},
 view(d){const doc=S.docs.find(x=>x.id===d.id);if(doc)S.modal={k:'view',id:d.id,f:docForm(doc)};},
 close(){S.modal=null;},
 shade(d,e){if(e.target.classList.contains('shade'))S.modal=null;},
 async 'doc-save'(){const m=S.modal,id=S.pid;const body={...m.f};if(body.type!=='usage'||!body.month)body.submit=false;
   const r=await api(`/api/docs/${m.id}`,jsonBody({method:'PATCH',body}));
   if(!r.ok){m.error=r.body.error||'저장하지 못했습니다.';return;}
   await Promise.all([loadDocs(),loadPatients()]);if(id===S.pid){S.modal=null;toast('고친 것을 저장했습니다.');}},
 'del-ask'(){S.modal={k:'del',id:S.modal.id};},
 async 'del-ok'(){const m=S.modal;const r=await api(`/api/docs/${m.id}`,{method:'DELETE'});
   if(!r.ok){m.error=r.body.error||'지우지 못했습니다.';return;}
   S.modal=null;await Promise.all([loadDocs(),loadPatients(),loadStatus()]);toast('휴지통으로 보냈습니다.');},
 'move-pick'(){S.modal={k:'move',id:S.modal.id,q:'',to:null};},
 'move-to'(d){S.modal.to=+d.id;S.modal.error='';},'move-back'(){S.modal.to=null;},
 async 'move-ok'(){const m=S.modal,from=S.pid,to=pat(m.to);const r=await api(`/api/docs/${m.id}`,jsonBody({method:'PATCH',body:{boxNo:m.to,fromBoxNo:from}}));
   if(!r.ok){m.error=r.body.error||'옮기지 못했습니다.';return;}
   S.modal=null;await Promise.all([loadDocs(),loadPatients()]);toast(`${esc(to.name)}에게 옮겼습니다.`);},
 async 'lk-yes'(){const m=S.modal,L=m.L,p=L.patient;
   const body=L.decision==='confirm_chart_no'?{chartNo:L.newChartNo}:{chartKey:m.i};
   const r=await api(`/api/patients/${p.boxNo}`,jsonBody({method:'PUT',body}));
   if(!r.ok){m.error=r.body.error||'고치지 못했습니다.';return;}
   S.modal=null;await loadPatients();await sel(p.boxNo);},
 async 'lk-open'(d){S.modal=null;await sel(+d.id);},
 'lk-new'(){const m=S.modal;S.modal={k:'patient',id:null,f:{name:'',chartNo:m.c||'',birth6:'',state:'use',memo:'',contractStart:'',returnDay:'',chartKey:m.i||''}};},
 'roster-pick'(){if(S.saving){toast('저장이 끝난 뒤에 해 주세요.');return;}const el=document.getElementById('rfile');if(el)el.click();return false;},
 'roster-link'(d,e){S.modal.links[d.i]=e.target.checked;},
 async 'roster-commit'(){const m=S.modal;m.busy=true;m.error='';render();
   const r=await api('/api/patients/sync',jsonBody({body:{roster:m.roster,commit:true,links:Object.keys(m.links).filter(i=>m.links[i])}}));m.busy=false;
   if(!r.ok){m.error=r.body.error||'반영하지 못했습니다.';return;}
   const d=r.body.done,left=r.body.plan.conflict+r.body.plan.link;S.modal=null;S.snap=null;await Promise.all([loadPatients(),loadStatus()]);
   toast(`명단을 반영했습니다 — 새로 ${d.created}명 · 바뀜 ${d.updated}명 · 이어짐 ${d.linked}명.`+(d.failed?` 넣지 못한 줄 ${d.failed}.`:'')+(left?` 남은 확인 ${left}건은 그대로 두었습니다.`:''));},
 'new-patient'(){S.modal={k:'patient',id:null,f:{name:'',chartNo:'',birth6:'',state:'use',memo:'',contractStart:'',returnDay:''}};},
 'edit-patient'(){const p=pat(S.pid);if(p)S.modal={k:'patient',id:p.boxNo,f:{name:p.name,chartNo:p.chartNo,birth6:p.birth6,state:p.state,memo:p.memo,contractStart:p.contractStart||'',returnDay:p.returnDay||''}};},
 async 'patient-save'(){const m=S.modal;const r=m.id?await api(`/api/patients/${m.id}`,jsonBody({method:'PUT',body:m.f})):await api('/api/patients',jsonBody({body:m.f}));
   if(!r.ok){m.error=r.body.error||'저장하지 못했습니다.';return;}
   const p=r.body.data.patient,warn=(r.body.data.warnings||[])[0];S.modal=null;await Promise.all([loadPatients(),loadStatus()]);
   if(!m.id)await sel(p.boxNo);toast((m.id?'저장했습니다.':`${esc(p.name)} 환자를 등록했습니다.`)+(warn?' '+esc(warn):''));}
};
document.addEventListener('click',async e=>{const b=e.target.closest('[data-act]');if(!b||b.disabled)return;const f=A[b.dataset.act];if(!f)return;
  if(b.dataset.act==='shade'&&!e.target.classList.contains('shade'))return;
  const r=await f(b.dataset,e);if(r!==false)render();});
document.addEventListener('change',e=>{const t=e.target;
  if(t.id==='files'){const files=[...t.files];t.value='';addFiles(files);return;}
  if(t.id==='bfiles'){const files=[...t.files];t.value='';addBatchFiles(files);return;}
  if(t.id==='rfile'){const f=t.files[0];t.value='';if(f)readRoster(f);return;}
  if(t.id==='cmonth'&&S.claim&&/^\d{4}-\d{2}$/.test(t.value)){S.claim.month=t.value;S.claim.out=null;loadClaim().then(render);return;}
  if(t.dataset.chg){const u=S.up[+t.dataset.i];if(!u)return;u[t.dataset.chg]=t.value;
    if(t.dataset.chg==='type'){u.typeFrom='';u.touched=true;u.cands=null;u.use=u.type==='usage'?(u.month?'claim':'unknown'):'';}
    if(t.dataset.chg==='month'&&u.type==='usage')u.use=u.month?'claim':'unknown';
    S.keep=true;render();return;}
  if(t.dataset.f&&S.modal&&S.modal.f){S.modal.f[t.dataset.f]=t.type==='checkbox'?t.checked:t.value;if(t.dataset.f==='type')render();}
});
document.addEventListener('input',e=>{const t=e.target;
  if(t.id==='lq'){S.lq=t.value;const pl=document.querySelector('.prows');if(pl)pl.innerHTML=listRows(listData().rows);return;}   /* 치는 동안 줄만 다시 그린다(한글 입력이 끊기지 않게) */
  if(t.id==='mq'&&S.modal){S.modal.q=t.value;const p=pat(S.pid);const q=t.value.trim().toLowerCase();
    document.getElementById('mrows').innerHTML=moveRows(S.patients.map(x=>x.patient).filter(x=>x.boxNo!==p.boxNo&&(!q||(x.name+' '+x.chartNo+' '+x.birth6).toLowerCase().includes(q))));return;}
  if(t.dataset.f&&S.modal&&S.modal.f&&t.tagName!=='SELECT'&&t.type!=='checkbox')S.modal.f[t.dataset.f]=t.value;
  if(t.dataset.w&&S.wiz){S.wiz[t.dataset.w]=t.value;if(t.dataset.w==='dataRoot')S.wiz.pickNote='';}
  if(t.dataset.b&&S.bform)S.bform[t.dataset.b]=t.value;
});
/* ↑↓ 로 목록의 앞·뒤 환자 */
document.addEventListener('keydown',e=>{
  if(e.key==='Escape'&&S.modal){S.modal=null;render();return;}
  if(S.scene!=='patient'||S.modal||!['ArrowUp','ArrowDown'].includes(e.key))return;const t=e.target.tagName;if(t==='SELECT'||t==='TEXTAREA'||(t==='INPUT'&&e.target.id!=='lq'))return;
  const i=S.order.indexOf(S.pid);const n=e.key==='ArrowDown'?Math.min(S.order.length-1,i+1):Math.max(0,i<0?0:i-1);
  if(S.order[n]!=null&&S.order[n]!==S.pid){e.preventDefault();S.keep=true;sel(S.order[n]).then(()=>{const s2=document.querySelector('.prow.sel');if(s2)s2.scrollIntoView({block:'nearest'});});}});
/* 파일은 가운데 칸(고른 환자)에만 놓을 수 있다. 다른 곳에 놓으면 아무 일도 없다(브라우저가 파일을 열어 버리지 않게 막기만 한다). */
document.addEventListener('dragover',e=>{e.preventDefault();const z=e.target.closest&&e.target.closest('#drop,#bdrop');document.querySelectorAll('.drop.over').forEach(x=>x!==z&&x.classList.remove('over'));if(z&&!S.saving){z.classList.add('over');e.dataTransfer.dropEffect='copy';}else e.dataTransfer.dropEffect='none';});
document.addEventListener('dragleave',e=>{if(!e.relatedTarget)document.querySelectorAll('.drop.over').forEach(x=>x.classList.remove('over'));});
document.addEventListener('drop',e=>{e.preventDefault();document.querySelectorAll('.drop.over').forEach(x=>x.classList.remove('over'));
  const z=e.target.closest&&e.target.closest('#drop,#bdrop');if(!z)return;
  if(z.id==='bdrop'){if(S.scene==='usage')addBatchFiles([...e.dataTransfer.files]);}else if(S.pid&&!S.saving)addFiles([...e.dataTransfer.files]);});

(async function start(){
  render();await loadSetup();
  if(!S.setup){render();setTimeout(()=>location.reload(),3000);return;}
  if(S.setup.role===''){S.scene='setup';S.wiz=newWiz();render();return;}   /* 처음 켠 PC: 역할부터 */
  if(location.hash==='#admin'){history.replaceState(null,'',location.pathname);S.scene='admin';}
  await Promise.all([loadTypes(),loadPatients(),loadStatus(),S.scene==='admin'?loadAdmin():null]);render();
  /* 주소 뒤 #p=<서류함 번호> 로 그 환자를 바로 연다(차트의 서류 버튼이 쓸 자리). 읽자마자 주소에서 지운다. */
  const m=location.hash.match(/(?:^#|&)p=(\d+)/);if(m){history.replaceState(null,'',location.pathname);if(pat(+m[1]))await sel(+m[1]);}
  try{const r=await fetch('/api/open/next?after=0',{cache:'no-store'});if(r.ok){const b=await r.json();S.openSeq=b.seq;if(b.roster){S.rosterSeq=b.roster.seq;S.rosterSeen={created:b.roster.created,updated:b.roster.updated,check:b.roster.check};}if(b.open)openFromChart(b.c,b.i);}}catch(e){}
  setInterval(pollOpen,1000);
  setInterval(async()=>{const was=S.online,link=S.link;await loadStatus();if((!was&&S.online)||(link&&!S.link)){await loadPatients();await loadDocs();render();}},15000);
  /* 보관 PC: 다른 PC가 연결을 청하면 확인 숫자 창을 띄운다. */
  if(S.setup.role==='store'&&S.setup.lanPort) setInterval(async()=>{
    if(S.saving||S.restarting)return;if(!await loadSetup())return;
    const w=(S.setup.waiting||[])[0];
    if(w&&(!S.modal||S.modal.k==='pair')){if(!S.modal||S.modal.req.id!==w.id){S.modal={k:'pair',req:w};render();}}
    else if(!w&&S.modal&&S.modal.k==='pair'){S.modal=null;render();}
    else if(S.scene==='admin'&&!S.modal){S.keep=true;render();}
  },3000);
})();
